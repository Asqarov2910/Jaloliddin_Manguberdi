using UnityEngine;

public class Tower : MonoBehaviour
{
    public float     range    = 6f;
    public float     fireRate = 1.5f;
    public int       damage   = 25;
    public Transform firePoint;

    private float   cooldown;
    private Transform target;

    void Update()
    {
        if (GameManager.Instance == null || GameManager.Instance.gameOver) return;

        FindTarget();
        if (target == null) return;

        Vector3 dir = target.position - transform.position;
        dir.y = 0;
        if (dir != Vector3.zero)
            transform.rotation = Quaternion.Slerp(transform.rotation,
                Quaternion.LookRotation(dir), Time.deltaTime * 10f);

        cooldown -= Time.deltaTime;
        if (cooldown <= 0f) { Shoot(); cooldown = 1f / fireRate; }
    }

    void FindTarget()
    {
        EnemyUnit[] all = FindObjectsOfType<EnemyUnit>();
        float best = Mathf.Infinity;
        target = null;

        foreach (EnemyUnit e in all)
        {
            float d = Vector3.Distance(transform.position, e.transform.position);
            if (d <= range && d < best) { best = d; target = e.transform; }
        }
    }

    void Shoot()
    {
        if (target == null) return;

        Vector3 pos = firePoint != null
            ? firePoint.position
            : transform.position + Vector3.up * 1.5f;

        GameObject b = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        b.name = "Bullet";
        b.transform.position   = pos;
        b.transform.localScale = Vector3.one * 0.18f;
        var bmat = new Material(Shader.Find("Unlit/Color"));
        bmat.color = new Color(1f, 0.85f, 0.1f);
        b.GetComponent<Renderer>().material = bmat;
        Destroy(b.GetComponent<SphereCollider>());

        Bullet bullet = b.AddComponent<Bullet>();
        bullet.speed  = 14f;
        bullet.damage = damage;
        bullet.SetTarget(target);
        SoundManager.Instance?.PlayShoot();
    }

    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.cyan;
        Gizmos.DrawWireSphere(transform.position, range);
    }
}
