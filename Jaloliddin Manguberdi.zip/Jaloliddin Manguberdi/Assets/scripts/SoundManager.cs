using UnityEngine;
using System.Collections;

public class SoundManager : MonoBehaviour
{
    public static SoundManager Instance;

    private AudioSource musicSource;
    private AudioSource sfxSource;

    private AudioClip bgMusic;
    private AudioClip shootClip;
    private AudioClip enemyDieClip;
    private AudioClip castleHitClip;
    private AudioClip waveStartClip;
    private AudioClip victoryClip;
    private AudioClip defeatClip;

    void Awake()
    {
        Instance = this;

        musicSource = gameObject.AddComponent<AudioSource>();
        musicSource.loop   = true;
        musicSource.volume = 0.35f;

        sfxSource = gameObject.AddComponent<AudioSource>();
        sfxSource.loop   = false;
        sfxSource.volume = 0.7f;

        GenerateAllClips();

        musicSource.clip = bgMusic;
        musicSource.Play();
    }

    // ── AUDIO IJRO ───────────────────────────────
    public void PlayShoot()      => sfxSource.PlayOneShot(shootClip,    0.5f);
    public void PlayEnemyDie()   => sfxSource.PlayOneShot(enemyDieClip, 0.6f);
    public void PlayCastleHit()  => sfxSource.PlayOneShot(castleHitClip,0.9f);
    public void PlayWaveStart()  => sfxSource.PlayOneShot(waveStartClip,0.8f);
    public void PlayVictory()    { musicSource.Stop(); sfxSource.PlayOneShot(victoryClip, 1f); }
    public void PlayDefeat()     { musicSource.Stop(); sfxSource.PlayOneShot(defeatClip,  1f); }

    public void SetMusicVolume(float v) => musicSource.volume = v;

    // ── PROTSESSUAL AUDIO GENERATSIYA ────────────
    void GenerateAllClips()
    {
        int sr = AudioSettings.outputSampleRate;

        bgMusic      = GenerateBgMusic(sr);
        shootClip    = GenerateShoot(sr);
        enemyDieClip = GenerateEnemyDie(sr);
        castleHitClip= GenerateCastleHit(sr);
        waveStartClip= GenerateWaveStart(sr);
        victoryClip  = GenerateVictory(sr);
        defeatClip   = GenerateDefeat(sr);
    }

    // Fon musiqasi: past-chiroyli ambient loop
    AudioClip GenerateBgMusic(int sr)
    {
        int len = sr * 8;
        float[] data = new float[len];
        float[] freqs = { 110f, 138.6f, 165f, 196f, 220f };

        for (int i = 0; i < len; i++)
        {
            float t    = (float)i / sr;
            float beat = Mathf.Sin(t * 2f * Mathf.PI * 0.5f) * 0.3f + 0.7f;
            float s    = 0f;
            s += Mathf.Sin(t * 2f * Mathf.PI * freqs[0]) * 0.18f;
            s += Mathf.Sin(t * 2f * Mathf.PI * freqs[1]) * 0.12f;
            s += Mathf.Sin(t * 2f * Mathf.PI * freqs[2]) * 0.10f;
            s += Mathf.Sin(t * 2f * Mathf.PI * freqs[3]) * 0.08f;
            // Nog'ora urishi
            float drumT = t % 1.0f;
            s += Mathf.Exp(-drumT * 18f) * Mathf.Sin(drumT * 2f * Mathf.PI * 60f) * 0.25f;
            // Ohang chizig'i
            float melody = freqs[(int)(t * 1.5f) % freqs.Length];
            float mEnv   = Mathf.Clamp01(Mathf.Sin((t % 0.667f) / 0.667f * Mathf.PI));
            s += Mathf.Sin(t * 2f * Mathf.PI * melody * 2f) * mEnv * 0.07f;
            data[i] = s * beat * 0.6f;
        }

        // Fade in/out
        int fade = sr / 4;
        for (int i = 0; i < fade; i++)
        {
            float f = (float)i / fade;
            data[i]         *= f;
            data[len-1-i]   *= f;
        }

        AudioClip clip = AudioClip.Create("BGMusic", len, 1, sr, false);
        clip.SetData(data, 0);
        return clip;
    }

    // O'q ovozi: real kamondan uzilish + uchish "whoosh"
    AudioClip GenerateShoot(int sr)
    {
        int len = sr / 5; // 200ms — real o'q ovozi
        float[] data = new float[len];
        for (int i = 0; i < len; i++)
        {
            float t  = (float)i / sr;   // vaqt (sekund)
            float tN = (float)i / len;  // normalangan 0..1
            float s  = 0f;

            // ─ Kamon toridan bo'shalib ketish: keskin zarba ─
            float burstEnv = Mathf.Exp(-tN * 55f);
            float noise    = Mathf.Sin(t * 18371f) * Mathf.Sin(t * 9127f);
            s += burstEnv * noise * 0.55f;

            // ─ O'q uchishi: yuqori→past chastota ─
            float wFreq = 1400f * Mathf.Exp(-tN * 3.2f);
            float wEnv  = (1f - Mathf.Exp(-tN * 60f)) * Mathf.Exp(-tN * 5.5f);
            s += Mathf.Sin(t * 2f * Mathf.PI * wFreq) * wEnv * 0.38f;

            // ─ Kamon torining past rezonansi (thud) ─
            float bassEnv = Mathf.Exp(-tN * 18f);
            s += Mathf.Sin(t * 2f * Mathf.PI * 155f) * bassEnv * 0.32f;
            s += Mathf.Sin(t * 2f * Mathf.PI * 230f) * bassEnv * 0.18f;

            data[i] = Mathf.Clamp(s, -1f, 1f);
        }
        AudioClip c = AudioClip.Create("Shoot", len, 1, sr, false);
        c.SetData(data, 0); return c;
    }

    // Dushman o'lish: tushuvchi ton
    AudioClip GenerateEnemyDie(int sr)
    {
        int len = sr / 4;
        float[] data = new float[len];
        for (int i = 0; i < len; i++)
        {
            float t   = (float)i / len;
            float env = Mathf.Exp(-t * 5f);
            float freq= 400f - t * 300f;
            data[i] = (Mathf.Sin(t * 2f * Mathf.PI * freq) * 0.5f +
                       Mathf.Sin(t * 2f * Mathf.PI * freq * 1.5f) * 0.3f) * env;
        }
        AudioClip c = AudioClip.Create("EnemyDie", len, 1, sr, false);
        c.SetData(data, 0); return c;
    }

    // Qal'a zarba: past zarba
    AudioClip GenerateCastleHit(int sr)
    {
        int len = sr / 3;
        float[] data = new float[len];
        for (int i = 0; i < len; i++)
        {
            float t   = (float)i / len;
            float env = Mathf.Exp(-t * 4f);
            data[i] = (Mathf.Sin(t * 2f * Mathf.PI * 80f) * 0.6f +
                       (Random.value * 2f - 1f) * 0.15f) * env;
        }
        AudioClip c = AudioClip.Create("CastleHit", len, 1, sr, false);
        c.SetData(data, 0); return c;
    }

    // To'lqin boshlanishi: dramatik ko'tariluvchi ton
    AudioClip GenerateWaveStart(int sr)
    {
        int len = sr;
        float[] data = new float[len];
        float[] notes = { 220f, 277f, 330f, 440f };
        for (int n = 0; n < notes.Length; n++)
        {
            int s = n * sr / 4, e = (n + 1) * sr / 4;
            for (int i = s; i < e; i++)
            {
                float t   = (float)(i - s) / (sr / 4);
                float env = Mathf.Min(t * 4f, 1f) * Mathf.Exp(-(t - 0.8f) * 3f);
                data[i] += Mathf.Sin((float)(i) / sr * 2f * Mathf.PI * notes[n]) * env * 0.5f;
            }
        }
        AudioClip c = AudioClip.Create("WaveStart", len, 1, sr, false);
        c.SetData(data, 0); return c;
    }

    // G'alaba: tantanali akkordlar
    AudioClip GenerateVictory(int sr)
    {
        int len = sr * 3;
        float[] data = new float[len];
        float[] chord = { 261.6f, 329.6f, 392f, 523.2f };
        for (int i = 0; i < len; i++)
        {
            float t = (float)i / sr;
            float env = Mathf.Clamp01(t * 2f) * Mathf.Exp(-Mathf.Max(0f, t - 1.5f) * 1.2f);
            float s   = 0f;
            foreach (float f in chord)
                s += Mathf.Sin(t * 2f * Mathf.PI * f) * 0.18f;
            data[i] = s * env;
        }
        AudioClip c = AudioClip.Create("Victory", len, 1, sr, false);
        c.SetData(data, 0); return c;
    }

    // Mag'lubiyat: tushkunlik toni
    AudioClip GenerateDefeat(int sr)
    {
        int len = sr * 3;
        float[] data = new float[len];
        float[] notes = { 200f, 160f, 120f, 90f };
        for (int n = 0; n < notes.Length; n++)
        {
            int s = n * sr * 3 / 4, e = Mathf.Min((n + 1) * sr * 3 / 4, len);
            for (int i = s; i < e; i++)
            {
                float t   = (float)(i - s) / (sr * 3 / 4);
                float env = Mathf.Exp(-t * 1.5f);
                data[i] += Mathf.Sin((float)i / sr * 2f * Mathf.PI * notes[n]) * env * 0.4f;
            }
        }
        AudioClip c = AudioClip.Create("Defeat", len, 1, sr, false);
        c.SetData(data, 0); return c;
    }
}
