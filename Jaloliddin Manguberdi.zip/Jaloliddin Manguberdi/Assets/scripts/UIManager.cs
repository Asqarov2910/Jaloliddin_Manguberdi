using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class UIManager : MonoBehaviour
{
    public static UIManager Instance;

    [HideInInspector] public TextMeshProUGUI goldText;
    [HideInInspector] public TextMeshProUGUI healthText;
    [HideInInspector] public TextMeshProUGUI waveText;
    [HideInInspector] public Slider          castleHpBar;

    [HideInInspector] public GameObject      banner;
    [HideInInspector] public TextMeshProUGUI bannerText;

    [HideInInspector] public Image[]            towerBtnBgs;
    [HideInInspector] public TextMeshProUGUI[]  towerCostTexts;
    [HideInInspector] public Color[]            towerBaseColors;
    [HideInInspector] public GameObject         cancelBtn;

    [HideInInspector] public GameObject      endPanel;
    [HideInInspector] public TextMeshProUGUI endTitle;
    [HideInInspector] public TextMeshProUGUI endSub;
    [HideInInspector] public Button          restartBtn;

    [HideInInspector] public GameObject startScreen;
    [HideInInspector] public GameObject pauseOverlay;

    private Coroutine bannerRoutine;
    private int       gold;
    private int[]     costs;
    private int       sel = -1;

    private static readonly Color C_SELECTED = new Color(0.92f, 0.78f, 0.08f, 1.00f);

    void Awake() => Instance = this;

    void Update()
    {
        if (GameManager.Instance == null) return;
        if (goldText    != null) goldText.text    = GameManager.Instance.currentGold   + " oltin";
        if (healthText  != null) healthText.text  = GameManager.Instance.castleHealth.ToString();
        if (castleHpBar != null) castleHpBar.value = GameManager.Instance.castleHealth;
    }

    void Start()
    {
        int maxHp = GameManager.Instance.castleHealth;
        if (castleHpBar != null) { castleHpBar.maxValue = maxHp; castleHpBar.value = maxHp; }
        restartBtn?.onClick.AddListener(GameManager.Instance.RestartGame);
        UpdateGold(GameManager.Instance.currentGold);
        UpdateHealth(GameManager.Instance.castleHealth);
        if (banner)       banner.SetActive(false);
        if (cancelBtn)    cancelBtn.SetActive(false);
        if (endPanel)     endPanel.SetActive(false);
        if (pauseOverlay) pauseOverlay.SetActive(false);
        if (startScreen)  startScreen.SetActive(true); // Start ekranini ko'rsat
    }

    public void UpdateGold(int v)
    {
        gold = v;
        if (goldText != null) goldText.text = v + " oltin";
        Refresh();
    }

    public void UpdateHealth(int v)
    {
        if (healthText != null) healthText.text = v.ToString();
        if (castleHpBar != null) castleHpBar.value = v;
    }

    public void UpdateWave(int cur, int total)
    {
        if (waveText != null) waveText.text = "To'lqin " + cur + "/" + total;
    }

    public void ShowBanner(string line1, string line2 = "")
    {
        if (bannerRoutine != null) StopCoroutine(bannerRoutine);
        bannerRoutine = StartCoroutine(BannerAnim(line1, line2));
    }

    IEnumerator BannerAnim(string l1, string l2)
    {
        if (banner == null) yield break;
        if (bannerText != null)
            bannerText.text = string.IsNullOrEmpty(l2) ? l1 : l1 + "\n" + l2;
        banner.SetActive(true);
        CanvasGroup cg = banner.GetComponent<CanvasGroup>();
        if (cg == null) cg = banner.AddComponent<CanvasGroup>();
        for (float t = 0; t < 0.4f; t += Time.unscaledDeltaTime) { cg.alpha = t / 0.4f; yield return null; }
        cg.alpha = 1f;
        yield return new WaitForSecondsRealtime(2.5f);
        for (float t = 0; t < 0.5f; t += Time.unscaledDeltaTime) { cg.alpha = 1f - t / 0.5f; yield return null; }
        banner.SetActive(false);
    }

    // Start ekranini yashir (fade bilan)
    public void HideStartScreen()
    {
        if (startScreen != null) StartCoroutine(FadeOutAndHide(startScreen));
    }

    IEnumerator FadeOutAndHide(GameObject obj)
    {
        CanvasGroup cg = obj.GetComponent<CanvasGroup>();
        if (cg == null) cg = obj.AddComponent<CanvasGroup>();
        for (float t = 0; t < 0.6f; t += Time.unscaledDeltaTime)
        {
            cg.alpha = 1f - t / 0.6f;
            yield return null;
        }
        obj.SetActive(false);
    }

    // Pauza overlay ko'rsat/yashir
    public void ShowPauseOverlay(bool show)
    {
        if (pauseOverlay != null) pauseOverlay.SetActive(show);
    }

    public void SetCosts(int[] c) => costs = c;

    public void SetSelected(int index)
    {
        sel = index;
        if (cancelBtn) cancelBtn.SetActive(index >= 0);
        Refresh();
    }

    void Refresh()
    {
        if (towerBtnBgs == null || costs == null) return;
        for (int i = 0; i < towerBtnBgs.Length; i++)
        {
            if (towerBtnBgs[i] == null) continue;
            bool  ok      = i < costs.Length && gold >= costs[i];
            Color baseCol = (towerBaseColors != null && i < towerBaseColors.Length)
                ? towerBaseColors[i]
                : new Color(0.14f, 0.14f, 0.20f);

            if (i == sel)
                towerBtnBgs[i].color = Color.Lerp(baseCol, C_SELECTED, 0.55f);
            else if (!ok)
                towerBtnBgs[i].color = new Color(baseCol.r * 0.45f, baseCol.g * 0.45f, baseCol.b * 0.45f, 0.90f);
            else
                towerBtnBgs[i].color = baseCol;

            if (towerCostTexts != null && i < towerCostTexts.Length && towerCostTexts[i] != null)
                towerCostTexts[i].color = ok
                    ? new Color(1f, 0.88f, 0.15f)
                    : new Color(0.50f, 0.30f, 0.30f);
        }
    }

    public void ShowEndScreen(bool victory)
    {
        if (endPanel) endPanel.SetActive(true);
        if (endTitle) endTitle.text = victory ? "G'ALABA!" : "MAG'LUBIYAT!";

        string lvl = GameManager.selectedLevel == GameManager.GameLevel.Easy   ? "OSON" :
                     GameManager.selectedLevel == GameManager.GameLevel.Hard   ? "QIYIN" : "O'RTA";

        if (endSub) endSub.text = victory
            ? "Jaloliddin Manguberdi\nXorazm qal'asini himoya qildi!\n[ " + lvl + " daraja ]"
            : "Qal'a quladi...\nMo'g'ullar g'olib keldi.\n[ " + lvl + " daraja ]";
    }
}
