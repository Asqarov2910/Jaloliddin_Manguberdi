using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

// Jaloliddin Manguberdi portreti va motivatsion gaplar tizimi
public class HeroSystem : MonoBehaviour
{
    public static HeroSystem Instance;

    private GameObject    portraitPanel;
    private TextMeshProUGUI quoteText;
    private Image           portraitBg;
    private Coroutine       quoteCoroutine;

    // Motivatsion gaplar — o'zbekcha
    private static readonly string[] WaveQuotes = {
        "Xorazmni himoya qilish — bizning burchimiz!",
        "Mo'g'ullar bu yerda mag'lub bo'ladi!",
        "Oldinga, jasur jangchilar!",
        "Qal'a bizning uyimiz — uni asrang!",
        "Har bir o'q — vatanimiz uchun!",
    };

    private static readonly string[] KillQuotes = {
        "Barakalla! Davom eting!",
        "Xorazm ruhi tirik!",
        "Dushman orqaga chekinyapti!",
        "Yaxshi zarba!",
        "Ular bizni yengolay demaydi!",
    };

    private static readonly string[] DamageQuotes = {
        "Qal'ani qo'ldan bermang!",
        "Mustahkam turing, jangchilar!",
        "Ko'proq minorat quringlar!",
        "Ular oldinga kiryapti, to'singlar!",
        "Qal'amiz xavf ostida — tezroq!",
    };

    private static readonly string[] VictoryLines = {
        "G'ALABA! Xorazm hech qachon taslim bo'lmaydi!",
        "Jaloliddin Manguberdi nomi abadiy!",
    };

    void Awake() => Instance = this;

    public void Init(Canvas canvas)
    {
        BuildPortraitUI(canvas);
    }

    // ── UI QURILMASI ─────────────────────────────
    void BuildPortraitUI(Canvas canvas)
    {
        // Portret paneli — chap quyi burchak
        portraitPanel = new GameObject("HeroPanel");
        portraitPanel.transform.SetParent(canvas.transform, false);

        RectTransform panRt = portraitPanel.AddComponent<RectTransform>();
        panRt.anchorMin = new Vector2(0f, 0f);
        panRt.anchorMax = new Vector2(0f, 0f);
        panRt.pivot     = new Vector2(0f, 0f);
        panRt.sizeDelta = new Vector2(280f, 310f);
        panRt.anchoredPosition = new Vector2(10f, 205f); // minora paneli ustida

        // Fon panel
        Image panBg = portraitPanel.AddComponent<Image>();
        panBg.color = new Color(0.05f, 0.04f, 0.08f, 0.85f);

        // Oltin chegara
        AddBorder(portraitPanel, new Color(0.75f, 0.58f, 0.12f, 0.95f), 3f);

        // Portret rasmi
        GameObject portrait = new GameObject("Portrait");
        portrait.transform.SetParent(portraitPanel.transform, false);
        Image pImg = portrait.AddComponent<Image>();
        RectTransform pRt = portrait.GetComponent<RectTransform>();
        pRt.anchorMin = new Vector2(0.05f, 0.42f);
        pRt.anchorMax = new Vector2(0.95f, 0.98f);
        pRt.offsetMin = pRt.offsetMax = Vector2.zero;

        Texture2D tex = Resources.Load<Texture2D>("JaloliddinPortrait");
        if (tex != null)
        {
            pImg.sprite = Sprite.Create(tex,
                new Rect(0, 0, tex.width, tex.height),
                new Vector2(0.5f, 0.5f));
            pImg.preserveAspect = true;
            pImg.color = Color.white;
        }
        else
        {
            pImg.color = new Color(0.35f, 0.22f, 0.12f, 1f);
            // Fallback: "JM" harflari
            GameObject initials = new GameObject("Initials");
            initials.transform.SetParent(portrait.transform, false);
            TextMeshProUGUI initTxt = initials.AddComponent<TextMeshProUGUI>();
            initTxt.text      = "J\nM";
            initTxt.fontSize  = 62;
            initTxt.color     = new Color(0.88f, 0.78f, 0.55f, 0.6f);
            initTxt.alignment = TextAlignmentOptions.Center;
            RectTransform iRt = initials.GetComponent<RectTransform>();
            iRt.anchorMin = Vector2.zero; iRt.anchorMax = Vector2.one;
            iRt.offsetMin = iRt.offsetMax = Vector2.zero;
        }

        // Ism matn
        GameObject nameObj = new GameObject("HeroName");
        nameObj.transform.SetParent(portraitPanel.transform, false);
        TextMeshProUGUI nameTxt = nameObj.AddComponent<TextMeshProUGUI>();
        nameTxt.text      = "JALOLIDDIN\nMANGUBERDI";
        nameTxt.fontSize  = 20;
        nameTxt.color     = new Color(0.92f, 0.82f, 0.50f);
        nameTxt.alignment = TextAlignmentOptions.Center;
        RectTransform nRt = nameObj.GetComponent<RectTransform>();
        nRt.anchorMin = new Vector2(0f, 0.26f);
        nRt.anchorMax = new Vector2(1f, 0.42f);
        nRt.offsetMin = nRt.offsetMax = Vector2.zero;

        // Gap ko'rsatish maydoni
        GameObject quoteObj = new GameObject("QuoteBg");
        quoteObj.transform.SetParent(portraitPanel.transform, false);
        Image qBg = quoteObj.AddComponent<Image>();
        qBg.color = new Color(0.10f, 0.08f, 0.14f, 0.95f);
        RectTransform qRt = quoteObj.GetComponent<RectTransform>();
        qRt.anchorMin = new Vector2(0f, 0f);
        qRt.anchorMax = new Vector2(1f, 0.26f);
        qRt.offsetMin = qRt.offsetMax = Vector2.zero;

        GameObject quoteTextObj = new GameObject("QuoteText");
        quoteTextObj.transform.SetParent(quoteObj.transform, false);
        quoteText = quoteTextObj.AddComponent<TextMeshProUGUI>();
        quoteText.text      = "Xorazmni himoya qilish —\nbizning burchimiz!";
        quoteText.fontSize  = 17;
        quoteText.color     = new Color(0.95f, 0.92f, 0.80f);
        quoteText.alignment = TextAlignmentOptions.Center;
        RectTransform qtRt = quoteTextObj.GetComponent<RectTransform>();
        qtRt.anchorMin = Vector2.zero; qtRt.anchorMax = Vector2.one;
        qtRt.offsetMin = new Vector2(6, 4); qtRt.offsetMax = new Vector2(-6, -4);
    }

    void AddBorder(GameObject parent, Color color, float width)
    {
        string[] sides = { "Top", "Bottom", "Left", "Right" };
        foreach (string s in sides)
        {
            GameObject line = new GameObject("Border_" + s);
            line.transform.SetParent(parent.transform, false);
            line.AddComponent<Image>().color = color;
            RectTransform rt = line.GetComponent<RectTransform>();
            switch (s)
            {
                case "Top":
                    rt.anchorMin=new Vector2(0,1); rt.anchorMax=new Vector2(1,1);
                    rt.sizeDelta=new Vector2(0,width); rt.anchoredPosition=Vector2.zero;
                    break;
                case "Bottom":
                    rt.anchorMin=Vector2.zero; rt.anchorMax=new Vector2(1,0);
                    rt.sizeDelta=new Vector2(0,width); rt.anchoredPosition=Vector2.zero;
                    break;
                case "Left":
                    rt.anchorMin=Vector2.zero; rt.anchorMax=new Vector2(0,1);
                    rt.sizeDelta=new Vector2(width,0); rt.anchoredPosition=Vector2.zero;
                    break;
                case "Right":
                    rt.anchorMin=new Vector2(1,0); rt.anchorMax=Vector2.one;
                    rt.sizeDelta=new Vector2(width,0); rt.anchoredPosition=Vector2.zero;
                    break;
            }
        }
    }

    // ── TASHQI CHAQIRUVLAR ────────────────────────
    public void OnWaveStart(int waveNum)
    {
        SoundManager.Instance?.PlayWaveStart();
        ShowQuote(WaveQuotes[(waveNum - 1) % WaveQuotes.Length]);
    }

    public void OnEnemyKilled()
    {
        // Har 4 ta o'ldirishda bir marta
        if (Random.value > 0.25f) return;
        ShowQuote(KillQuotes[Random.Range(0, KillQuotes.Length)]);
        SoundManager.Instance?.PlayEnemyDie();
    }

    public void OnCastleHit()
    {
        SoundManager.Instance?.PlayCastleHit();
        ShowQuote(DamageQuotes[Random.Range(0, DamageQuotes.Length)]);
    }

    public void OnVictory()
    {
        SoundManager.Instance?.PlayVictory();
        ShowQuote(VictoryLines[0]);
    }

    public void OnDefeat()
    {
        SoundManager.Instance?.PlayDefeat();
        ShowQuote("Qal'a quladi... Lekin Jaloliddin abadiy!");
    }

    void ShowQuote(string text)
    {
        if (quoteCoroutine != null) StopCoroutine(quoteCoroutine);
        quoteCoroutine = StartCoroutine(AnimateQuote(text));
    }

    IEnumerator AnimateQuote(string text)
    {
        if (quoteText == null) yield break;

        // Tez almashtirish
        quoteText.text  = text;
        quoteText.color = new Color(1f, 0.95f, 0.70f);

        // Bir necha marta miltillash
        for (int i = 0; i < 3; i++)
        {
            quoteText.color = new Color(1f, 0.95f, 0.70f);
            yield return new WaitForSeconds(0.12f);
            quoteText.color = new Color(0.95f, 0.92f, 0.80f);
            yield return new WaitForSeconds(0.12f);
        }
        quoteText.color = new Color(0.95f, 0.92f, 0.80f);
    }
}
