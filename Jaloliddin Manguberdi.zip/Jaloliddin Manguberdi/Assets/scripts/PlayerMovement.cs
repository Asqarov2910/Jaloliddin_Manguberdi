// Bu fayl ishlatilmaydi. GameBootstrap.cs ishga tushiradi.
