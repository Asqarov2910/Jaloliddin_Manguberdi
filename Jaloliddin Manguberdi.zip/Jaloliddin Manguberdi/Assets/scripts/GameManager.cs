using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;

    // ─── Qiyinchilik darajasi ──────────────────────
    public enum GameLevel { Easy, Medium, Hard }
    public static GameLevel selectedLevel = GameLevel.Medium;

    public int castleHealth = 20;
    public int startGold    = 150;

    [HideInInspector] public int  currentGold;
    [HideInInspector] public bool gameOver;
    [HideInInspector] public bool gameStarted = false;
    [HideInInspector] public bool isPaused    = false;

    void Awake()
    {
        Instance = this;

        // Darajaga qarab sozlamalar
        switch (selectedLevel)
        {
            case GameLevel.Easy:
                castleHealth = 30;
                startGold    = 200;
                break;
            case GameLevel.Medium:
                castleHealth = 20;
                startGold    = 150;
                break;
            case GameLevel.Hard:
                castleHealth = 12;
                startGold    = 100;
                break;
        }

        currentGold = startGold;
    }

    public bool CanAfford(int amount) => currentGold >= amount;

    public void SpendGold(int amount)
    {
        currentGold -= amount;
        UIManager.Instance?.UpdateGold(currentGold);
    }

    public void EarnGold(int amount)
    {
        currentGold += amount;
        UIManager.Instance?.UpdateGold(currentGold);
    }

    public void StartGame()
    {
        gameStarted = true;
        UIManager.Instance?.HideStartScreen();
    }

    public void TogglePause()
    {
        if (gameOver || !gameStarted) return;
        isPaused      = !isPaused;
        Time.timeScale = isPaused ? 0f : 1f;
        UIManager.Instance?.ShowPauseOverlay(isPaused);
    }

    public void ResumeGame()
    {
        isPaused      = false;
        Time.timeScale = 1f;
        UIManager.Instance?.ShowPauseOverlay(false);
    }

    public void EnemyReachedCastle(int damage)
    {
        if (gameOver) return;
        castleHealth -= damage;
        UIManager.Instance?.UpdateHealth(castleHealth);
        HeroSystem.Instance?.OnCastleHit();
        if (castleHealth <= 0) EndGame(false);
    }

    public void EndGame(bool victory)
    {
        if (gameOver) return;
        gameOver      = true;
        isPaused      = false;
        Time.timeScale = 1f;
        UIManager.Instance?.ShowEndScreen(victory);
        if (victory) HeroSystem.Instance?.OnVictory();
        else         HeroSystem.Instance?.OnDefeat();
    }

    public void RestartGame()
    {
        Time.timeScale = 1f;
        SceneManager.LoadScene(0);
    }
}
