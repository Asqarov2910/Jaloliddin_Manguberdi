using System.Collections;
using UnityEngine;

public class WaveManager : MonoBehaviour
{
    public static WaveManager Instance;
    public static Vector3 SpawnPos;

    public enum EnemyType
    {
        Soldier,       // 1. Piyoda askar
        ShieldBearer,  // 2. Qalqonli jangchi
        Cavalry,       // 3. Otliq askar
        HeavyCavalry,  // 4. Og'ir otliq
        EliteGuard,    // 5. Elit qo'riqchi
        ChingizKhan    // 6. BOSS
    }

    private int  waveIndex = 0;
    private int  alive     = 0;
    private bool spawning  = false;

    private struct Wave
    {
        public int       count;
        public float     interval;
        public float     speed;
        public int       hp;
        public int       gold;
        public EnemyType type;
        public string    label;
        public int       bossCount;
        public EnemyType bossType;
    }

    // ─── OSON: 4 to'lqin ──────────────────────────
    private static readonly Wave[] wavesEasy = new Wave[]
    {
        new Wave { count=4,  interval=2.0f, speed=1.8f, hp=40,  gold=20,
                   type=EnemyType.Soldier,      label="Piyoda askarlar" },
        new Wave { count=6,  interval=1.8f, speed=1.4f, hp=90,  gold=28,
                   type=EnemyType.ShieldBearer, label="Qalqonli jangchilar" },
        new Wave { count=8,  interval=1.5f, speed=3.5f, hp=75,  gold=32,
                   type=EnemyType.Cavalry,      label="Otliq qo'shin" },
        new Wave { count=7,  interval=1.2f, speed=2.8f, hp=130, gold=40,
                   type=EnemyType.HeavyCavalry, label="Og'ir otliq qo'shin",
                   bossCount=1, bossType=EnemyType.EliteGuard },
    };

    // ─── O'RTA: 5 to'lqin ─────────────────────────
    private static readonly Wave[] wavesMedium = new Wave[]
    {
        new Wave { count=6,  interval=1.5f, speed=2.5f, hp=60,  gold=15,
                   type=EnemyType.Soldier,      label="Piyoda askarlar" },
        new Wave { count=10, interval=1.2f, speed=2.0f, hp=115, gold=22,
                   type=EnemyType.ShieldBearer, label="Qalqonli jangchilar" },
        new Wave { count=14, interval=1.0f, speed=4.0f, hp=100, gold=28,
                   type=EnemyType.Cavalry,      label="Otliq qo'shin" },
        new Wave { count=16, interval=0.8f, speed=3.5f, hp=195, gold=35,
                   type=EnemyType.HeavyCavalry, label="Og'ir otliq qo'shin" },
        new Wave { count=15, interval=0.8f, speed=3.0f, hp=220, gold=45,
                   type=EnemyType.EliteGuard,   label="Elit qo'riqchilar",
                   bossCount=1, bossType=EnemyType.ChingizKhan },
    };

    // ─── QIYIN: 6 to'lqin ─────────────────────────
    private static readonly Wave[] wavesHard = new Wave[]
    {
        new Wave { count=8,  interval=1.0f, speed=3.2f, hp=80,  gold=15,
                   type=EnemyType.Soldier,      label="Piyoda askarlar" },
        new Wave { count=12, interval=0.8f, speed=2.5f, hp=155, gold=18,
                   type=EnemyType.ShieldBearer, label="Qalqonli jangchilar" },
        new Wave { count=16, interval=0.7f, speed=4.8f, hp=130, gold=22,
                   type=EnemyType.Cavalry,      label="Otliq qo'shin" },
        new Wave { count=20, interval=0.6f, speed=4.2f, hp=255, gold=28,
                   type=EnemyType.HeavyCavalry, label="Og'ir otliq qo'shin" },
        new Wave { count=20, interval=0.5f, speed=3.8f, hp=310, gold=38,
                   type=EnemyType.EliteGuard,   label="Elit qo'riqchilar",
                   bossCount=1, bossType=EnemyType.ChingizKhan },
        new Wave { count=15, interval=0.5f, speed=3.5f, hp=290, gold=55,
                   type=EnemyType.EliteGuard,   label="⚠ CHINGIZXON HUJUMI!",
                   bossCount=3, bossType=EnemyType.ChingizKhan },
    };

    private Wave[] waves;

    void Awake()
    {
        Instance = this;
        switch (GameManager.selectedLevel)
        {
            case GameManager.GameLevel.Easy:   waves = wavesEasy;   break;
            case GameManager.GameLevel.Hard:   waves = wavesHard;   break;
            default:                           waves = wavesMedium; break;
        }
    }

    void Start() => StartCoroutine(RunWaves());

    IEnumerator RunWaves()
    {
        yield return new WaitUntil(() => GameManager.Instance != null && GameManager.Instance.gameStarted);
        yield return new WaitForSeconds(2f);

        while (waveIndex < waves.Length)
        {
            if (GameManager.Instance.gameOver) yield break;
            Wave w = waves[waveIndex];
            UIManager.Instance?.UpdateWave(waveIndex + 1, waves.Length);
            UIManager.Instance?.ShowBanner(
                (waveIndex + 1) + " - TO'LQIN",
                w.count + " ta " + w.label + " hujum qilmoqda!");
            HeroSystem.Instance?.OnWaveStart(waveIndex + 1);
            yield return SpawnWave(w);
            yield return new WaitUntil(() => alive <= 0 && !spawning);
            waveIndex++;
            if (waveIndex < waves.Length)
            {
                UIManager.Instance?.ShowBanner("Qal'ani mustahkamlang!", "8 soniya...");
                yield return new WaitForSeconds(8f);
            }
        }
        if (!GameManager.Instance.gameOver) GameManager.Instance.EndGame(true);
    }

    IEnumerator SpawnWave(Wave w)
    {
        spawning = true;
        alive    = w.count + w.bossCount;

        for (int i = 0; i < w.count; i++)
        {
            if (GameManager.Instance.gameOver) { spawning = false; yield break; }
            SpawnEnemy(w.type, w.speed, w.hp, w.gold);
            yield return new WaitForSeconds(w.interval);
        }

        // Boss(lar) to'lqin oxirida keladi
        for (int i = 0; i < w.bossCount; i++)
        {
            if (GameManager.Instance.gameOver) { spawning = false; yield break; }
            if (i == 0 && w.bossType == EnemyType.ChingizKhan)
                UIManager.Instance?.ShowBanner("⚠ CHINGIZXON!", "U shaxsan qo'shinni boshqarmoqda!");
            SpawnBossUnit(w.bossType);
            yield return new WaitForSeconds(2.2f);
        }

        spawning = false;
    }

    void SpawnEnemy(EnemyType t, float speed, int hp, int gold)
    {
        switch (t)
        {
            case EnemyType.Soldier:      SpawnSoldier(speed, hp, gold);      break;
            case EnemyType.ShieldBearer: SpawnShieldBearer(speed, hp, gold); break;
            case EnemyType.Cavalry:      SpawnCavalry(speed, hp, gold);      break;
            case EnemyType.HeavyCavalry: SpawnHeavyCavalry(speed, hp, gold); break;
            case EnemyType.EliteGuard:   SpawnEliteGuard(speed, hp, gold);   break;
            case EnemyType.ChingizKhan:  SpawnChingizKhan(speed, hp, gold);  break;
        }
    }

    void SpawnBossUnit(EnemyType t)
    {
        switch (t)
        {
            case EnemyType.EliteGuard:  SpawnEliteGuard(3.2f, 500, 90);  break;
            case EnemyType.ChingizKhan: SpawnChingizKhan(2.8f, 900, 160); break;
        }
    }

    // ═══════════════════════════════════════════════
    // 1. PIYODA ASKAR  (oddiy, yengil qurollangan)
    // ═══════════════════════════════════════════════
    void SpawnSoldier(float speed, int hp, int gold)
    {
        GameObject root = NewRoot("MongolAskar", 1.5f);

        Color skin   = new Color(0.82f, 0.62f, 0.42f);
        Color armor  = new Color(0.30f, 0.20f, 0.08f);
        Color helmet = new Color(0.40f, 0.30f, 0.10f);
        Color metal  = new Color(0.55f, 0.50f, 0.45f);
        Color wood   = new Color(0.50f, 0.25f, 0.08f);

        P(root, PrimitiveType.Cube,    new Vector3(0,      1.00f, 0),    new Vector3(0.55f, 0.65f, 0.30f), armor);
        P(root, PrimitiveType.Sphere,  new Vector3(0,      1.72f, 0),    new Vector3(0.38f, 0.38f, 0.38f), skin);
        P(root, PrimitiveType.Sphere,  new Vector3(0,      1.88f, 0),    new Vector3(0.42f, 0.22f, 0.42f), helmet);
        P(root, PrimitiveType.Capsule, new Vector3(-0.38f, 0.95f, 0),    new Vector3(0.14f, 0.28f, 0.14f), armor);
        P(root, PrimitiveType.Capsule, new Vector3( 0.38f, 0.95f, 0),    new Vector3(0.14f, 0.28f, 0.14f), armor);
        P(root, PrimitiveType.Capsule, new Vector3(-0.16f, 0.28f, 0),    new Vector3(0.16f, 0.30f, 0.16f), armor);
        P(root, PrimitiveType.Capsule, new Vector3( 0.16f, 0.28f, 0),    new Vector3(0.16f, 0.30f, 0.16f), armor);
        P(root, PrimitiveType.Cube,    new Vector3( 0.55f, 1.05f, 0),    new Vector3(0.06f, 0.55f, 0.06f), metal);
        P(root, PrimitiveType.Cube,    new Vector3(-0.50f, 1.00f, 0.12f),new Vector3(0.28f, 0.38f, 0.05f), wood);

        Collider2Unit(root, speed, hp, gold, dmg:1, h:2.0f, r:0.30f, cy:1.0f);
    }

    // ═══════════════════════════════════════════════
    // 2. QALQONLI JANGCHI  (ko'proq HP, sekinroq)
    // ═══════════════════════════════════════════════
    void SpawnShieldBearer(float speed, int hp, int gold)
    {
        GameObject root = NewRoot("QalqonliJangchi", 1.6f);

        Color skin   = new Color(0.78f, 0.58f, 0.40f);
        Color armor  = new Color(0.35f, 0.40f, 0.48f); // po'lat ko'k-kulrang
        Color helmet = new Color(0.28f, 0.32f, 0.40f);
        Color crest  = new Color(0.72f, 0.58f, 0.12f); // oltin krest
        Color shield = new Color(0.50f, 0.25f, 0.08f); // yog'och qalqon
        Color srim   = new Color(0.65f, 0.55f, 0.15f); // oltin rim
        Color spear  = new Color(0.58f, 0.54f, 0.48f);

        P(root, PrimitiveType.Cube,    new Vector3(0,      1.05f, 0),    new Vector3(0.60f, 0.70f, 0.35f), armor);
        P(root, PrimitiveType.Sphere,  new Vector3(0,      1.78f, 0),    new Vector3(0.40f, 0.40f, 0.40f), skin);
        P(root, PrimitiveType.Cube,    new Vector3(0,      1.95f, 0),    new Vector3(0.46f, 0.28f, 0.46f), helmet);
        P(root, PrimitiveType.Cube,    new Vector3(0,      2.12f, 0),    new Vector3(0.08f, 0.22f, 0.44f), crest);
        // Qo'llar
        P(root, PrimitiveType.Capsule, new Vector3(-0.40f, 0.98f, 0),    new Vector3(0.15f, 0.30f, 0.15f), armor);
        P(root, PrimitiveType.Capsule, new Vector3( 0.40f, 0.98f, 0),    new Vector3(0.15f, 0.30f, 0.15f), armor);
        // Oyoqlar
        P(root, PrimitiveType.Capsule, new Vector3(-0.18f, 0.28f, 0),    new Vector3(0.17f, 0.32f, 0.17f), armor);
        P(root, PrimitiveType.Capsule, new Vector3( 0.18f, 0.28f, 0),    new Vector3(0.17f, 0.32f, 0.17f), armor);
        // Katta qalqon (chap tomon)
        P(root, PrimitiveType.Cube,    new Vector3(-0.58f, 1.00f, 0.18f),new Vector3(0.07f, 0.85f, 0.60f), srim);
        P(root, PrimitiveType.Cube,    new Vector3(-0.56f, 1.00f, 0.18f),new Vector3(0.06f, 0.76f, 0.52f), shield);
        // Qalqon markazida oltin belgi
        P(root, PrimitiveType.Sphere,  new Vector3(-0.54f, 1.10f, 0.18f),new Vector3(0.05f, 0.12f, 0.12f), crest);
        // Naiza (o'ng tomon)
        P(root, PrimitiveType.Cube,    new Vector3( 0.52f, 1.40f, 0),    new Vector3(0.05f, 0.85f, 0.05f), spear);
        P(root, PrimitiveType.Sphere,  new Vector3( 0.52f, 1.85f, 0),    new Vector3(0.09f, 0.14f, 0.09f), new Color(0.80f,0.75f,0.70f));

        Collider2Unit(root, speed, hp, gold, dmg:2, h:2.0f, r:0.32f, cy:1.0f);
    }

    // ═══════════════════════════════════════════════
    // 3. OTLIQ ASKAR  (tez, otda, naiza)
    // ═══════════════════════════════════════════════
    void SpawnCavalry(float speed, int hp, int gold)
    {
        GameObject root = NewRoot("OtliqAskar", 1.8f);

        Color horseSkin  = new Color(0.48f, 0.30f, 0.14f);
        Color horseDark  = new Color(0.28f, 0.16f, 0.05f);
        Color riderArmor = new Color(0.45f, 0.32f, 0.10f);
        Color skin       = new Color(0.82f, 0.62f, 0.42f);
        Color helmet     = new Color(0.50f, 0.38f, 0.08f);
        Color metal      = new Color(0.60f, 0.56f, 0.50f);

        // ── At ──
        P(root, PrimitiveType.Cube,    new Vector3(0,       0.58f,  0),    new Vector3(0.65f, 0.55f, 1.40f), horseSkin);
        P(root, PrimitiveType.Cube,    new Vector3(0,       0.72f,  1.05f),new Vector3(0.30f, 0.32f, 0.58f), horseSkin);
        P(root, PrimitiveType.Cube,    new Vector3(0,       0.96f,  0.55f),new Vector3(0.08f, 0.24f, 0.52f), horseDark); // jal
        P(root, PrimitiveType.Cube,    new Vector3(0,       0.56f, -0.88f),new Vector3(0.09f, 0.28f, 0.09f), horseDark); // dum
        // 4 oyoq
        P(root, PrimitiveType.Capsule, new Vector3(-0.25f, 0.10f,  0.46f),new Vector3(0.12f, 0.28f, 0.12f), horseDark);
        P(root, PrimitiveType.Capsule, new Vector3( 0.25f, 0.10f,  0.46f),new Vector3(0.12f, 0.28f, 0.12f), horseDark);
        P(root, PrimitiveType.Capsule, new Vector3(-0.25f, 0.10f, -0.46f),new Vector3(0.12f, 0.28f, 0.12f), horseDark);
        P(root, PrimitiveType.Capsule, new Vector3( 0.25f, 0.10f, -0.46f),new Vector3(0.12f, 0.28f, 0.12f), horseDark);

        // ── Chavandoz ──
        P(root, PrimitiveType.Cube,    new Vector3(0,       1.35f,  0.08f),new Vector3(0.52f, 0.55f, 0.28f), riderArmor);
        P(root, PrimitiveType.Sphere,  new Vector3(0,       1.90f,  0.08f),new Vector3(0.34f, 0.34f, 0.34f), skin);
        P(root, PrimitiveType.Sphere,  new Vector3(0,       2.04f,  0.08f),new Vector3(0.38f, 0.20f, 0.38f), helmet);
        P(root, PrimitiveType.Capsule, new Vector3(-0.36f,  1.32f,  0.08f),new Vector3(0.13f, 0.24f, 0.13f), riderArmor);
        P(root, PrimitiveType.Capsule, new Vector3( 0.36f,  1.32f,  0.08f),new Vector3(0.13f, 0.24f, 0.13f), riderArmor);
        // Naiza oldinga qaratilgan
        P(root, PrimitiveType.Cube,    new Vector3( 0.55f,  1.55f,  0.55f),new Vector3(0.05f, 0.05f, 1.30f), metal);
        P(root, PrimitiveType.Sphere,  new Vector3( 0.55f,  1.55f,  1.22f),new Vector3(0.10f, 0.10f, 0.18f), new Color(0.82f,0.78f,0.72f));

        // Cavalry uchun kattaroq collider (ot+rider)
        CapsuleCollider col = root.AddComponent<CapsuleCollider>();
        col.height = 3.5f; col.radius = 0.40f;
        col.center = new Vector3(0, 1.3f, 0);
        AttachUnit(root, speed, hp, gold, dmg:1);
    }

    // ═══════════════════════════════════════════════
    // 4. OG'IR OTLIQ  (zirh kiygan ot + og'ir jangchi)
    // ═══════════════════════════════════════════════
    void SpawnHeavyCavalry(float speed, int hp, int gold)
    {
        GameObject root = NewRoot("OgirOtliq", 2.0f);

        Color horseArmor = new Color(0.28f, 0.28f, 0.34f); // po'lat barding
        Color horseSkin  = new Color(0.18f, 0.11f, 0.05f); // qora ot
        Color riderArmor = new Color(0.30f, 0.28f, 0.34f); // to'q po'lat
        Color goldC      = new Color(0.72f, 0.56f, 0.08f);
        Color skin       = new Color(0.78f, 0.58f, 0.38f);
        Color metal      = new Color(0.55f, 0.52f, 0.48f);

        // ── Zirhlangan ot ──
        P(root, PrimitiveType.Cube,    new Vector3(0,       0.62f,  0),    new Vector3(0.70f, 0.58f, 1.52f), horseArmor);
        P(root, PrimitiveType.Cube,    new Vector3(0,       0.76f,  1.08f),new Vector3(0.33f, 0.34f, 0.62f), horseArmor);
        P(root, PrimitiveType.Cube,    new Vector3(0,       0.90f,  0),    new Vector3(0.72f, 0.05f, 1.54f), goldC); // oltin chiziq
        P(root, PrimitiveType.Capsule, new Vector3(-0.28f,  0.10f,  0.50f),new Vector3(0.14f, 0.30f, 0.14f), horseSkin);
        P(root, PrimitiveType.Capsule, new Vector3( 0.28f,  0.10f,  0.50f),new Vector3(0.14f, 0.30f, 0.14f), horseSkin);
        P(root, PrimitiveType.Capsule, new Vector3(-0.28f,  0.10f, -0.50f),new Vector3(0.14f, 0.30f, 0.14f), horseSkin);
        P(root, PrimitiveType.Capsule, new Vector3( 0.28f,  0.10f, -0.50f),new Vector3(0.14f, 0.30f, 0.14f), horseSkin);

        // ── Og'ir zirhlangan chavandoz ──
        P(root, PrimitiveType.Cube,    new Vector3(0,       1.42f,  0.10f),new Vector3(0.60f, 0.65f, 0.34f), riderArmor);
        P(root, PrimitiveType.Sphere,  new Vector3(0,       2.02f,  0.10f),new Vector3(0.36f, 0.36f, 0.36f), skin);
        P(root, PrimitiveType.Cube,    new Vector3(0,       2.20f,  0.10f),new Vector3(0.48f, 0.30f, 0.48f), riderArmor); // to'rtburchak dubulg'a
        P(root, PrimitiveType.Cube,    new Vector3(0,       2.13f,  0.28f),new Vector3(0.38f, 0.10f, 0.07f), goldC);      // vizor
        P(root, PrimitiveType.Cube,    new Vector3(0,       1.82f,  0.10f),new Vector3(0.66f, 0.06f, 0.36f), goldC);      // yelka zirhi chiziq
        P(root, PrimitiveType.Capsule, new Vector3(-0.42f,  1.40f,  0.10f),new Vector3(0.17f, 0.27f, 0.17f), riderArmor);
        P(root, PrimitiveType.Capsule, new Vector3( 0.42f,  1.40f,  0.10f),new Vector3(0.17f, 0.27f, 0.17f), riderArmor);
        // Og'ir naiza
        P(root, PrimitiveType.Cube,    new Vector3( 0.62f,  1.58f,  0.60f),new Vector3(0.07f, 0.07f, 1.50f), metal);
        P(root, PrimitiveType.Cube,    new Vector3( 0.62f,  1.58f,  1.38f),new Vector3(0.15f, 0.15f, 0.22f), goldC);

        CapsuleCollider col = root.AddComponent<CapsuleCollider>();
        col.height = 4.0f; col.radius = 0.45f;
        col.center = new Vector3(0, 1.5f, 0);
        AttachUnit(root, speed, hp, gold, dmg:2);
    }

    // ═══════════════════════════════════════════════
    // 5. ELIT QO'RIQCHI  (oltin zirh, qizil plum, katta)
    // ═══════════════════════════════════════════════
    void SpawnEliteGuard(float speed, int hp, int gold)
    {
        GameObject root = NewRoot("ElitQoriqchi", 1.9f);

        Color armor  = new Color(0.55f, 0.42f, 0.05f); // oltin zirh
        Color trim   = new Color(0.75f, 0.60f, 0.08f);
        Color dark   = new Color(0.18f, 0.14f, 0.02f);
        Color skin   = new Color(0.72f, 0.50f, 0.32f);
        Color plume  = new Color(0.85f, 0.10f, 0.08f); // qizil plum
        Color blade  = new Color(0.88f, 0.86f, 0.82f); // yorqin po'lat

        // Gavda
        P(root, PrimitiveType.Cube,    new Vector3(0,      1.12f,  0),    new Vector3(0.64f, 0.82f, 0.34f), armor);
        P(root, PrimitiveType.Cube,    new Vector3(0,      1.28f,  0.20f),new Vector3(0.56f, 0.52f, 0.06f), trim);  // ko'krak zirhi
        // Bosh
        P(root, PrimitiveType.Sphere,  new Vector3(0,      1.95f,  0),    new Vector3(0.42f, 0.42f, 0.42f), skin);
        P(root, PrimitiveType.Cube,    new Vector3(0,      2.15f,  0),    new Vector3(0.50f, 0.37f, 0.50f), armor); // dubulg'a
        P(root, PrimitiveType.Cube,    new Vector3(0,      2.08f,  0.27f),new Vector3(0.30f, 0.12f, 0.07f), dark);  // vizor
        // Qizil plum
        P(root, PrimitiveType.Cube,    new Vector3(0,      2.55f,  0),    new Vector3(0.10f, 0.42f, 0.10f), plume);
        // Yelka zirhi (katta)
        P(root, PrimitiveType.Cube,    new Vector3(-0.50f, 1.45f,  0),    new Vector3(0.30f, 0.22f, 0.30f), armor);
        P(root, PrimitiveType.Cube,    new Vector3( 0.50f, 1.45f,  0),    new Vector3(0.30f, 0.22f, 0.30f), armor);
        // Qo'llar
        P(root, PrimitiveType.Capsule, new Vector3(-0.46f, 1.05f,  0),    new Vector3(0.16f, 0.30f, 0.16f), armor);
        P(root, PrimitiveType.Capsule, new Vector3( 0.46f, 1.05f,  0),    new Vector3(0.16f, 0.30f, 0.16f), armor);
        // Oyoqlar
        P(root, PrimitiveType.Capsule, new Vector3(-0.20f, 0.28f,  0),    new Vector3(0.19f, 0.36f, 0.19f), armor);
        P(root, PrimitiveType.Capsule, new Vector3( 0.20f, 0.28f,  0),    new Vector3(0.19f, 0.36f, 0.19f), armor);
        // Katta qilich
        P(root, PrimitiveType.Cube,    new Vector3( 0.62f, 1.12f,  0),    new Vector3(0.07f, 0.96f, 0.07f), blade);
        P(root, PrimitiveType.Cube,    new Vector3( 0.62f, 1.60f,  0),    new Vector3(0.05f, 0.06f, 0.36f), trim);  // qo'riqchi
        P(root, PrimitiveType.Cube,    new Vector3( 0.62f, 0.66f,  0),    new Vector3(0.12f, 0.24f, 0.12f), trim);  // dasta
        P(root, PrimitiveType.Sphere,  new Vector3( 0.62f, 0.56f,  0),    new Vector3(0.14f, 0.14f, 0.14f), new Color(0.90f,0.10f,0.10f)); // qimmatbaho tosh
        // Qalqon
        P(root, PrimitiveType.Cube,    new Vector3(-0.62f, 1.10f,  0.22f),new Vector3(0.07f, 0.82f, 0.56f), dark);
        P(root, PrimitiveType.Cube,    new Vector3(-0.60f, 1.10f,  0.22f),new Vector3(0.06f, 0.70f, 0.46f), armor);
        P(root, PrimitiveType.Sphere,  new Vector3(-0.58f, 1.18f,  0.22f),new Vector3(0.06f, 0.14f, 0.14f), trim);  // qalqon markazida

        Collider2Unit(root, speed, hp, gold, dmg:3, h:2.2f, r:0.34f, cy:1.1f);
    }

    // ═══════════════════════════════════════════════
    // 6. CHINGIZXON  ─ BOSS (qora ot, qizil chopon, toj)
    // ═══════════════════════════════════════════════
    void SpawnChingizKhan(float speed, int hp, int gold)
    {
        GameObject root = NewRoot("ChingizXon", 2.8f);

        Color robe   = new Color(0.55f, 0.04f, 0.04f); // to'q qizil chopon
        Color robeD  = new Color(0.68f, 0.06f, 0.06f); // yorqinroq qizil
        Color goldC  = new Color(0.88f, 0.70f, 0.08f);
        Color dark   = new Color(0.10f, 0.08f, 0.03f);
        Color skin   = new Color(0.68f, 0.46f, 0.26f);
        Color fur    = new Color(0.90f, 0.86f, 0.80f); // oq mo'yna
        Color blade  = new Color(0.92f, 0.90f, 0.86f);
        // At rangi
        Color bhorse = new Color(0.12f, 0.08f, 0.04f); // qora ot
        Color bgold  = new Color(0.78f, 0.60f, 0.06f);

        // ── Qora shohona ot ──
        P(root, PrimitiveType.Cube,    new Vector3(0,       0.55f,  0),    new Vector3(0.72f, 0.60f, 1.56f), bhorse);
        P(root, PrimitiveType.Cube,    new Vector3(0,       0.70f,  1.10f),new Vector3(0.34f, 0.36f, 0.64f), bhorse);
        P(root, PrimitiveType.Cube,    new Vector3(0,       0.55f,  0),    new Vector3(0.05f, 0.62f, 1.58f), bgold);  // yon oltin chiziq
        P(root, PrimitiveType.Cube,    new Vector3(0,       0.88f,  0),    new Vector3(0.74f, 0.05f, 1.58f), bgold);  // ustki oltin chiziq
        P(root, PrimitiveType.Cube,    new Vector3(0,       0.96f,  0.55f),new Vector3(0.09f, 0.26f, 0.55f), bhorse); // jal
        P(root, PrimitiveType.Capsule, new Vector3(-0.28f,  0.08f,  0.52f),new Vector3(0.14f, 0.32f, 0.14f), bhorse);
        P(root, PrimitiveType.Capsule, new Vector3( 0.28f,  0.08f,  0.52f),new Vector3(0.14f, 0.32f, 0.14f), bhorse);
        P(root, PrimitiveType.Capsule, new Vector3(-0.28f,  0.08f, -0.52f),new Vector3(0.14f, 0.32f, 0.14f), bhorse);
        P(root, PrimitiveType.Capsule, new Vector3( 0.28f,  0.08f, -0.52f),new Vector3(0.14f, 0.32f, 0.14f), bhorse);

        // ── Chingizxon gavdasi ──
        // Keng qizil chopon
        P(root, PrimitiveType.Cube,    new Vector3(0,       1.40f,  0.08f),new Vector3(0.76f, 0.88f, 0.38f), robe);
        P(root, PrimitiveType.Cube,    new Vector3(0,       0.96f,  0.08f),new Vector3(0.78f, 0.10f, 0.40f), fur);   // pastki mo'yna
        P(root, PrimitiveType.Cube,    new Vector3(0,       1.86f,  0.08f),new Vector3(0.84f, 0.12f, 0.40f), fur);   // ustki mo'yna
        // Oltin ko'krak zirhi
        P(root, PrimitiveType.Cube,    new Vector3(0,       1.50f,  0.28f),new Vector3(0.54f, 0.58f, 0.07f), goldC);
        // Chopon markazida oltin naqsh
        P(root, PrimitiveType.Cube,    new Vector3(0,       1.40f,  0.28f),new Vector3(0.08f, 0.86f, 0.05f), goldC);
        // Qizil shoh to'n (orqa)
        P(root, PrimitiveType.Cube,    new Vector3(0,       1.50f, -0.30f),new Vector3(0.62f, 0.88f, 0.06f), robeD);

        // ── Bosh ──
        P(root, PrimitiveType.Sphere,  new Vector3(0,       2.14f,  0.08f),new Vector3(0.46f, 0.46f, 0.46f), skin);
        // Dubulg'a asosi
        P(root, PrimitiveType.Cube,    new Vector3(0,       2.38f,  0.08f),new Vector3(0.54f, 0.24f, 0.54f), dark);
        // Oltin toj lentasi
        P(root, PrimitiveType.Cube,    new Vector3(0,       2.52f,  0.08f),new Vector3(0.56f, 0.08f, 0.56f), goldC);
        // Toj (3 ta tish)
        P(root, PrimitiveType.Cube,    new Vector3(0,       2.68f,  0.08f),new Vector3(0.09f, 0.32f, 0.09f), goldC); // markaz
        P(root, PrimitiveType.Cube,    new Vector3(-0.20f,  2.64f,  0.08f),new Vector3(0.07f, 0.22f, 0.07f), goldC);
        P(root, PrimitiveType.Cube,    new Vector3( 0.20f,  2.64f,  0.08f),new Vector3(0.07f, 0.22f, 0.07f), goldC);
        // Oltin mo'yna (dubulg'a ostida)
        P(root, PrimitiveType.Cube,    new Vector3(0,       2.30f,  0.08f),new Vector3(0.60f, 0.08f, 0.60f), fur);
        // Ko'zlar (g'azabli, qora)
        P(root, PrimitiveType.Sphere,  new Vector3(-0.13f,  2.16f,  0.30f),new Vector3(0.08f, 0.07f, 0.04f), dark);
        P(root, PrimitiveType.Sphere,  new Vector3( 0.13f,  2.16f,  0.30f),new Vector3(0.08f, 0.07f, 0.04f), dark);
        // Soqol
        P(root, PrimitiveType.Cube,    new Vector3(0,       1.98f,  0.28f),new Vector3(0.24f, 0.18f, 0.06f), dark);

        // ── Qo'llar ──
        P(root, PrimitiveType.Capsule, new Vector3(-0.54f,  1.44f,  0.08f),new Vector3(0.20f, 0.36f, 0.20f), robe);
        P(root, PrimitiveType.Capsule, new Vector3( 0.54f,  1.44f,  0.08f),new Vector3(0.20f, 0.36f, 0.20f), robe);
        // Oltin yelka yostiqchasi
        P(root, PrimitiveType.Cube,    new Vector3(-0.54f,  1.85f,  0.08f),new Vector3(0.34f, 0.14f, 0.34f), goldC);
        P(root, PrimitiveType.Cube,    new Vector3( 0.54f,  1.85f,  0.08f),new Vector3(0.34f, 0.14f, 0.34f), goldC);

        // ── Shohona qilich ──
        P(root, PrimitiveType.Cube,    new Vector3( 0.76f,  1.42f,  0.08f),new Vector3(0.08f, 1.18f, 0.08f), blade);
        P(root, PrimitiveType.Cube,    new Vector3( 0.76f,  2.02f,  0.08f),new Vector3(0.06f, 0.08f, 0.48f), goldC);   // qo'riqchi
        P(root, PrimitiveType.Cube,    new Vector3( 0.76f,  0.92f,  0.08f),new Vector3(0.14f, 0.28f, 0.14f), goldC);   // dasta
        P(root, PrimitiveType.Sphere,  new Vector3( 0.76f,  0.80f,  0.08f),new Vector3(0.16f, 0.16f, 0.16f), new Color(0.85f,0.10f,0.10f)); // qimmatbaho tosh

        // ── BOSS collider (kattaroq) ──
        CapsuleCollider col = root.AddComponent<CapsuleCollider>();
        col.height = 4.2f; col.radius = 0.48f;
        col.center = new Vector3(0, 1.4f, 0);

        EnemyUnit e = root.AddComponent<EnemyUnit>();
        e.speed         = speed;
        e.maxHealth     = hp;
        e.currentHealth = hp;
        e.goldReward    = gold;
        e.castleDamage  = 5; // Boss qal'aga 5 zarar beradi!
    }

    // ─── YORDAMCHI ────────────────────────────────
    GameObject NewRoot(string name, float scale)
    {
        GameObject g = new GameObject(name);
        g.transform.position   = SpawnPos;
        g.transform.localScale = new Vector3(scale, scale, scale);
        return g;
    }

    void P(GameObject parent, PrimitiveType type, Vector3 pos, Vector3 scale, Color color)
    {
        GameObject g = GameObject.CreatePrimitive(type);
        g.transform.SetParent(parent.transform);
        g.transform.localPosition = pos;
        g.transform.localScale    = scale;
        Material mat = new Material(Shader.Find("Unlit/Color"));
        mat.color = color;
        g.GetComponent<Renderer>().material = mat;
        Destroy(g.GetComponent<Collider>());
    }

    void Collider2Unit(GameObject root, float speed, int hp, int gold, int dmg,
                       float h, float r, float cy)
    {
        CapsuleCollider col = root.AddComponent<CapsuleCollider>();
        col.height = h; col.radius = r;
        col.center = new Vector3(0, cy, 0);
        AttachUnit(root, speed, hp, gold, dmg);
    }

    void AttachUnit(GameObject root, float speed, int hp, int gold, int dmg)
    {
        EnemyUnit e = root.AddComponent<EnemyUnit>();
        e.speed         = speed;
        e.maxHealth     = hp;
        e.currentHealth = hp;
        e.goldReward    = gold;
        e.castleDamage  = dmg;
    }

    public void OnEnemyRemoved() => alive = Mathf.Max(0, alive - 1);
}
