using UnityEngine;

public class Bullet : MonoBehaviour
{
    public float speed  = 14f;
    public int   damage = 25;

    private Transform target;

    public void SetTarget(Transform t) => target = t;

    void Update()
    {
        if (target == null) { Destroy(gameObject); return; }

        transform.position = Vector3.MoveTowards(
            transform.position, target.position, speed * Time.deltaTime);

        if (Vector3.Distance(transform.position, target.position) < 0.25f)
            Hit();
    }

    void Hit()
    {
        EnemyUnit e = target.GetComponent<EnemyUnit>()
                   ?? target.GetComponentInParent<EnemyUnit>();
        e?.TakeDamage(damage);
        Destroy(gameObject);
    }
}
