using UnityEngine;
using UnityEngine.UI;

public class EnemyUnit : MonoBehaviour
{
    public float speed        = 3f;
    public int   maxHealth    = 100;
    public int   currentHealth;
    public int   goldReward   = 20;
    public int   castleDamage = 1;

    private int  wpIndex = 0;
    private bool reached = false;
    private bool dead    = false;

    // ── HP bar (world-space) ──
    private GameObject  hpBarRoot;
    private Image       hpFill;

    void Start()
    {
        if (currentHealth <= 0) currentHealth = maxHealth;
        BuildHpBar();
    }

    void Update()
    {
        if (GameManager.Instance == null || GameManager.Instance.gameOver) return;
        if (WaypointPath.Instance == null || WaypointPath.Instance.Count == 0) return;

        if (wpIndex >= WaypointPath.Instance.Count) { ReachCastle(); return; }

        Transform wp  = WaypointPath.Instance.Get(wpIndex);
        Vector3   dir = (wp.position - transform.position).normalized;

        transform.position += dir * speed * Time.deltaTime;

        if (dir != Vector3.zero)
            transform.rotation = Quaternion.Slerp(transform.rotation,
                Quaternion.LookRotation(dir), Time.deltaTime * 8f);

        if (Vector3.Distance(transform.position, wp.position) < 0.3f)
            wpIndex++;

        // HP bar kamera tomon qaraydi
        if (hpBarRoot != null)
        {
            hpBarRoot.transform.rotation = Camera.main
                ? Camera.main.transform.rotation
                : Quaternion.identity;
        }
    }

    public void TakeDamage(int dmg)
    {
        if (dead || reached) return;
        currentHealth -= dmg;
        RefreshHpBar();
        if (currentHealth <= 0) Die();
    }

    void Die()
    {
        if (dead) return;
        dead = true;
        GameManager.Instance?.EarnGold(goldReward);
        WaveManager.Instance?.OnEnemyRemoved();
        HeroSystem.Instance?.OnEnemyKilled();
        Destroy(gameObject);
    }

    void ReachCastle()
    {
        if (reached) return;
        reached = true;
        GameManager.Instance?.EnemyReachedCastle(castleDamage);
        WaveManager.Instance?.OnEnemyRemoved();
        Destroy(gameObject);
    }

    // ── HP bar qurilishi ─────────────────────────
    void BuildHpBar()
    {
        // Dushman turi bo'yicha HP bar rangini va balandligini aniqlash
        bool isBoss   = gameObject.name.StartsWith("ChingizXon");
        bool isElite  = gameObject.name.StartsWith("Elit");
        bool isCav    = gameObject.name.StartsWith("Otliq") ||
                        gameObject.name.StartsWith("Ogir");

        float barY = isBoss ? 4.2f : isCav ? 3.5f : 2.4f;
        float barW = isBoss ? 1.4f : isElite ? 1.1f : 0.85f;

        Color fillColor = isBoss  ? new Color(0.90f, 0.10f, 0.10f) :
                          isElite ? new Color(0.85f, 0.60f, 0.05f) :
                          isCav   ? new Color(0.20f, 0.60f, 0.90f) :
                                    new Color(0.18f, 0.78f, 0.18f);

        // Root (world-space object)
        hpBarRoot = new GameObject("HpBar");
        hpBarRoot.transform.SetParent(transform);
        hpBarRoot.transform.localPosition = new Vector3(0, barY, 0);
        hpBarRoot.transform.localScale    = Vector3.one / transform.lossyScale.x;

        // Canvas
        Canvas cv = hpBarRoot.AddComponent<Canvas>();
        cv.renderMode = RenderMode.WorldSpace;
        RectTransform cvRt = hpBarRoot.GetComponent<RectTransform>();
        cvRt.sizeDelta = new Vector2(barW, 0.14f);

        // Fon (qora)
        GameObject bg = new GameObject("Bg");
        bg.transform.SetParent(hpBarRoot.transform, false);
        Image bgImg = bg.AddComponent<Image>();
        bgImg.color = new Color(0.08f, 0.08f, 0.08f, 0.88f);
        RectTransform bgRt = bg.GetComponent<RectTransform>();
        bgRt.anchorMin = Vector2.zero; bgRt.anchorMax = Vector2.one;
        bgRt.offsetMin = bgRt.offsetMax = Vector2.zero;

        // To'ldirgich (rang)
        GameObject fill = new GameObject("Fill");
        fill.transform.SetParent(hpBarRoot.transform, false);
        hpFill = fill.AddComponent<Image>();
        hpFill.color = fillColor;
        RectTransform fRt = fill.GetComponent<RectTransform>();
        fRt.anchorMin = Vector2.zero; fRt.anchorMax = Vector2.one;
        fRt.offsetMin = new Vector2(0.01f, 0.01f);
        fRt.offsetMax = new Vector2(-0.01f, -0.01f);

        // Boss uchun chiziq
        if (isBoss)
        {
            GameObject border = new GameObject("Border");
            border.transform.SetParent(hpBarRoot.transform, false);
            Image bImg = border.AddComponent<Image>();
            bImg.color = new Color(0.85f, 0.65f, 0.05f, 0.90f);
            RectTransform bRt = border.GetComponent<RectTransform>();
            bRt.anchorMin = Vector2.zero; bRt.anchorMax = new Vector2(1, 0);
            bRt.sizeDelta = new Vector2(0, 0.03f);
            bRt.anchoredPosition = Vector2.zero;
        }
    }

    void RefreshHpBar()
    {
        if (hpFill == null) return;
        float pct = Mathf.Clamp01((float)currentHealth / maxHealth);
        hpFill.GetComponent<RectTransform>().anchorMax = new Vector2(pct, 1f);
    }
}
