using UnityEngine;

public class WaypointPath : MonoBehaviour
{
    public static WaypointPath Instance;

    private Transform[] points;

    void Awake() => Instance = this;

    public void Init(Transform[] waypoints) => points = waypoints;

    public int   Count      => points != null ? points.Length : 0;
    public Transform Get(int i) => points[i];
}
