using UnityEngine;

public class TowerPlacer : MonoBehaviour
{
    public static TowerPlacer Instance;

    public struct TowerConfig
    {
        public string name;
        public string desc;
        public int    cost;
        public float  range;
        public float  fireRate;
        public int    damage;
        public Color  color;
    }

    private TowerConfig[] configs;
    private int           selected = -1;
    private GameObject    preview;

    void Awake() => Instance = this;
    public void SetConfigs(TowerConfig[] cfg) => configs = cfg;

    void Update()
    {
        if (GameManager.Instance == null) return;
        if (!GameManager.Instance.gameStarted) return;
        if (GameManager.Instance.gameOver || GameManager.Instance.isPaused) return;
        if (selected < 0) return;
        HandleInput();
    }

    void HandleInput()
    {
        if (Input.touchCount > 0)
        {
            Touch t = Input.GetTouch(0);
            if (t.phase == TouchPhase.Moved || t.phase == TouchPhase.Stationary)
                MovePreview(t.position);
            if (t.phase == TouchPhase.Ended && !OverUI(t.fingerId))
                TryPlace(t.position);
        }
        else
        {
            MovePreview(Input.mousePosition);
            if (Input.GetMouseButtonDown(0) && !OverUI(-1)) TryPlace(Input.mousePosition);
            if (Input.GetMouseButtonDown(1) || Input.GetKeyDown(KeyCode.Escape)) Cancel();
        }
    }

    bool OverUI(int id)
    {
        var es = UnityEngine.EventSystems.EventSystem.current;
        return es != null && (id >= 0 ? es.IsPointerOverGameObject(id) : es.IsPointerOverGameObject());
    }

    void MovePreview(Vector2 screen)
    {
        if (preview == null) return;
        Ray ray = Camera.main.ScreenPointToRay(screen);
        if (Physics.Raycast(ray, out RaycastHit hit, 300f))
            preview.transform.position = Snap(hit.point);
    }

    void TryPlace(Vector2 screen)
    {
        Ray ray = Camera.main.ScreenPointToRay(screen);
        if (!Physics.Raycast(ray, out RaycastHit hit, 300f)) return;
        TowerConfig cfg = configs[selected];
        if (!GameManager.Instance.CanAfford(cfg.cost))
        {
            UIManager.Instance?.ShowBanner("Yetarli oltin yo'q!", cfg.cost + " oltin kerak");
            return;
        }
        BuildTower(Snap(hit.point), cfg, selected);
        GameManager.Instance.SpendGold(cfg.cost);
    }

    void BuildTower(Vector3 pos, TowerConfig cfg, int type)
    {
        GameObject root = new GameObject(cfg.name);
        root.transform.position = pos;

        switch (type)
        {
            case 0: BuildArcherTower(root, cfg.color);   break;
            case 1: BuildBallista(root, cfg.color);      break;
            case 2: BuildCauldronTower(root, cfg.color); break;
            case 3: BuildHeroRider(root, cfg.color);     break;
            default: BuildArcherTower(root, cfg.color);  break;
        }

        bool isHero = (type == 3);

        // Kattalashtirish: minoralarga 1.4x, Jaloliddin 1.5x
        root.transform.localScale = isHero
            ? new Vector3(1.5f, 1.5f, 1.5f)
            : new Vector3(1.4f, 1.4f, 1.4f);

        BoxCollider col = root.AddComponent<BoxCollider>();
        col.center = isHero ? new Vector3(0, 1.7f, 0) : new Vector3(0, 1.5f, 0);
        col.size   = isHero ? new Vector3(1.5f, 3.5f, 2.0f) : new Vector3(1.2f, 3f, 1.2f);

        GameObject fp = new GameObject("FP");
        fp.transform.SetParent(root.transform);
        fp.transform.localPosition = isHero ? new Vector3(0.58f, 2.60f, 0.04f) : new Vector3(0, 3.2f, 0.5f);

        Tower t = root.AddComponent<Tower>();
        t.range = cfg.range; t.fireRate = cfg.fireRate;
        t.damage = cfg.damage; t.firePoint = fp.transform;
    }

    // ─── OK MINORASI ──────────────────────────────
    void BuildArcherTower(GameObject root, Color color)
    {
        Color stone = new Color(0.70f, 0.63f, 0.50f);
        Color dark  = new Color(0.45f, 0.40f, 0.32f);

        P(root, PrimitiveType.Cylinder, new Vector3(0, 0.15f, 0),    new Vector3(1.1f, 0.15f, 1.1f),   dark);
        P(root, PrimitiveType.Cube,     new Vector3(0, 1.2f,  0),    new Vector3(0.85f, 2.2f, 0.85f),  stone);
        P(root, PrimitiveType.Cube,     new Vector3(0, 2.55f, 0),    new Vector3(1.05f, 0.28f, 1.05f), dark);
        for (int i = 0; i < 4; i++)
        {
            float a = i * 90f * Mathf.Deg2Rad;
            P(root, PrimitiveType.Cube,
              new Vector3(Mathf.Cos(a) * 0.38f, 2.9f, Mathf.Sin(a) * 0.38f),
              new Vector3(0.22f, 0.35f, 0.22f), stone);
        }
        P(root, PrimitiveType.Cube, new Vector3(0, 1.5f, 0.44f),  new Vector3(0.14f, 0.32f, 0.04f), dark);
        P(root, PrimitiveType.Cube, new Vector3(0, 3.4f, 0),      new Vector3(0.05f, 0.6f, 0.05f),  dark);
        P(root, PrimitiveType.Cube, new Vector3(0.2f, 3.6f, 0),   new Vector3(0.36f, 0.18f, 0.04f), color);
    }

    // ─── BALLISTA ─────────────────────────────────
    void BuildBallista(GameObject root, Color color)
    {
        Color stone = new Color(0.55f, 0.48f, 0.38f);
        Color wood  = new Color(0.45f, 0.28f, 0.10f);
        Color metal = new Color(0.50f, 0.48f, 0.44f);

        P(root, PrimitiveType.Cube,     new Vector3(0, 0.2f, 0),      new Vector3(1.8f, 0.4f, 1.8f),    stone);
        P(root, PrimitiveType.Cube,     new Vector3(0, 0.75f, 0.8f),  new Vector3(1.8f, 0.7f, 0.15f),   stone);
        P(root, PrimitiveType.Cube,     new Vector3(0.8f, 0.75f, 0),  new Vector3(0.15f, 0.7f, 1.8f),   stone);
        P(root, PrimitiveType.Cube,     new Vector3(-0.8f, 0.75f, 0), new Vector3(0.15f, 0.7f, 1.8f),   stone);
        P(root, PrimitiveType.Cube,     new Vector3(0, 0.6f, -0.2f),  new Vector3(0.4f, 0.15f, 0.8f),   wood);
        P(root, PrimitiveType.Cube,     new Vector3(-0.55f, 0.72f, 0.1f), new Vector3(0.8f, 0.08f, 0.12f), wood);
        P(root, PrimitiveType.Cube,     new Vector3( 0.55f, 0.72f, 0.1f), new Vector3(0.8f, 0.08f, 0.12f), wood);
        P(root, PrimitiveType.Cylinder, new Vector3(0, 0.72f, -0.1f), new Vector3(0.05f, 0.5f, 0.05f),  metal);
        P(root, PrimitiveType.Cube,     new Vector3(0, 0.62f, -0.2f), new Vector3(0.12f, 0.12f, 0.12f), metal);
        P(root, PrimitiveType.Cube,     new Vector3(0.7f, 1.3f, 0.7f),  new Vector3(0.04f, 0.5f, 0.04f),  stone);
        P(root, PrimitiveType.Cube,     new Vector3(0.9f, 1.45f, 0.7f), new Vector3(0.35f, 0.15f, 0.04f), color);
    }

    // ─── QOZON MINORASI ───────────────────────────
    void BuildCauldronTower(GameObject root, Color color)
    {
        Color stone = new Color(0.60f, 0.54f, 0.42f);
        Color dark  = new Color(0.30f, 0.26f, 0.20f);
        Color metal = new Color(0.30f, 0.28f, 0.25f);
        Color fire  = new Color(0.95f, 0.45f, 0.05f);

        P(root, PrimitiveType.Cylinder, new Vector3(0, 0.12f, 0),  new Vector3(1.4f, 0.12f, 1.4f),  dark);
        P(root, PrimitiveType.Cube,     new Vector3(0, 0.9f,  0),  new Vector3(1.1f, 1.55f, 1.1f),  stone);
        P(root, PrimitiveType.Cube,     new Vector3(0, 1.75f, 0),  new Vector3(1.4f, 0.18f, 1.4f),  dark);
        P(root, PrimitiveType.Cylinder, new Vector3(0, 2.15f, 0),  new Vector3(0.85f, 0.40f, 0.85f),metal);
        P(root, PrimitiveType.Cylinder, new Vector3(0, 2.55f, 0),  new Vector3(0.90f, 0.08f, 0.90f),dark);
        P(root, PrimitiveType.Sphere,   new Vector3(0, 2.62f, 0),  new Vector3(0.55f, 0.28f, 0.55f),fire);
        float[] angles = { 0f, 120f, 240f };
        foreach (float a in angles)
        {
            float rad = a * Mathf.Deg2Rad;
            P(root, PrimitiveType.Cube,
              new Vector3(Mathf.Cos(rad) * 0.28f, 1.95f, Mathf.Sin(rad) * 0.28f),
              new Vector3(0.09f, 0.38f, 0.09f), dark);
        }
        for (int i = 0; i < 4; i++)
        {
            float a = i * 90f * Mathf.Deg2Rad;
            P(root, PrimitiveType.Cube,
              new Vector3(Mathf.Cos(a) * 0.60f, 2.05f, Mathf.Sin(a) * 0.60f),
              new Vector3(0.25f, 0.5f, 0.25f), stone);
        }
    }

    // ─── JALOLIDDIN — REAL OTLIQ QO'MONDON ──────────
    void BuildHeroRider(GameObject root, Color flagColor)
    {
        Color skin      = new Color(0.85f, 0.68f, 0.48f);
        Color armor     = new Color(0.65f, 0.50f, 0.10f);
        Color armorDark = new Color(0.42f, 0.32f, 0.05f);
        Color helmet    = new Color(0.72f, 0.58f, 0.08f);
        Color horse     = new Color(0.20f, 0.13f, 0.07f);
        Color mane      = new Color(0.10f, 0.06f, 0.02f);
        Color saddle    = new Color(0.42f, 0.22f, 0.06f);
        Color sword     = new Color(0.88f, 0.85f, 0.78f);
        Color cape      = new Color(0.72f, 0.06f, 0.06f);
        Color capeDark  = new Color(0.48f, 0.03f, 0.03f);
        Color shield    = new Color(0.52f, 0.10f, 0.08f);
        Color gold      = new Color(0.92f, 0.76f, 0.12f);
        Color dark      = new Color(0.12f, 0.09f, 0.06f);

        // ══ OT ══════════════════════════════════════
        P(root,  PrimitiveType.Cube,    new Vector3(0,    1.12f, 0.05f),  new Vector3(0.78f, 0.72f, 1.85f), horse);
        P(root,  PrimitiveType.Sphere,  new Vector3(0,    1.16f, 0.82f),  new Vector3(0.68f, 0.62f, 0.68f), horse);
        P(root,  PrimitiveType.Sphere,  new Vector3(0,    1.20f,-0.82f),  new Vector3(0.72f, 0.68f, 0.65f), horse);
        PR(root, PrimitiveType.Capsule, new Vector3(0,    1.55f, 1.18f),  new Vector3(0.33f, 0.52f, 0.33f), horse,  new Vector3(-35f, 0, 0));
        P(root,  PrimitiveType.Sphere,  new Vector3(0,    1.82f, 1.52f),  new Vector3(0.32f, 0.28f, 0.40f), horse);
        P(root,  PrimitiveType.Cube,    new Vector3(0,    1.68f, 1.72f),  new Vector3(0.22f, 0.16f, 0.26f), horse);
        P(root,  PrimitiveType.Cube,    new Vector3(-0.11f,1.98f, 1.48f), new Vector3(0.07f, 0.15f, 0.07f), mane);
        P(root,  PrimitiveType.Cube,    new Vector3( 0.11f,1.98f, 1.48f), new Vector3(0.07f, 0.15f, 0.07f), mane);
        P(root,  PrimitiveType.Sphere,  new Vector3(-0.15f,1.84f, 1.68f), new Vector3(0.06f, 0.06f, 0.04f), dark);
        P(root,  PrimitiveType.Sphere,  new Vector3( 0.15f,1.84f, 1.68f), new Vector3(0.06f, 0.06f, 0.04f), dark);
        // Yol (mane)
        P(root,  PrimitiveType.Cube,    new Vector3(0.01f, 1.72f, 1.25f), new Vector3(0.10f, 0.30f, 0.12f), mane);
        P(root,  PrimitiveType.Cube,    new Vector3(0.01f, 1.52f, 1.08f), new Vector3(0.10f, 0.26f, 0.10f), mane);
        P(root,  PrimitiveType.Cube,    new Vector3(0.01f, 1.35f, 0.92f), new Vector3(0.10f, 0.22f, 0.10f), mane);
        // Old oyoqlar (2 bo'g'imli)
        P(root,  PrimitiveType.Capsule, new Vector3(-0.25f, 0.68f, 0.62f), new Vector3(0.17f, 0.35f, 0.17f), horse);
        PR(root, PrimitiveType.Capsule, new Vector3(-0.25f, 0.18f, 0.70f), new Vector3(0.13f, 0.30f, 0.13f), horse, new Vector3(10f, 0, 0));
        P(root,  PrimitiveType.Capsule, new Vector3( 0.25f, 0.68f, 0.62f), new Vector3(0.17f, 0.35f, 0.17f), horse);
        PR(root, PrimitiveType.Capsule, new Vector3( 0.25f, 0.18f, 0.70f), new Vector3(0.13f, 0.30f, 0.13f), horse, new Vector3(10f, 0, 0));
        // Orqa oyoqlar (2 bo'g'imli)
        P(root,  PrimitiveType.Capsule, new Vector3(-0.25f, 0.68f,-0.60f), new Vector3(0.17f, 0.35f, 0.17f), horse);
        PR(root, PrimitiveType.Capsule, new Vector3(-0.25f, 0.18f,-0.52f), new Vector3(0.13f, 0.30f, 0.13f), horse, new Vector3(-8f, 0, 0));
        P(root,  PrimitiveType.Capsule, new Vector3( 0.25f, 0.68f,-0.60f), new Vector3(0.17f, 0.35f, 0.17f), horse);
        PR(root, PrimitiveType.Capsule, new Vector3( 0.25f, 0.18f,-0.52f), new Vector3(0.13f, 0.30f, 0.13f), horse, new Vector3(-8f, 0, 0));
        // Tuyoqlar
        P(root,  PrimitiveType.Cube,    new Vector3(-0.25f, 0.02f, 0.75f), new Vector3(0.17f, 0.06f, 0.19f), dark);
        P(root,  PrimitiveType.Cube,    new Vector3( 0.25f, 0.02f, 0.75f), new Vector3(0.17f, 0.06f, 0.19f), dark);
        P(root,  PrimitiveType.Cube,    new Vector3(-0.25f, 0.02f,-0.52f), new Vector3(0.17f, 0.06f, 0.19f), dark);
        P(root,  PrimitiveType.Cube,    new Vector3( 0.25f, 0.02f,-0.52f), new Vector3(0.17f, 0.06f, 0.19f), dark);
        // Dum
        PR(root, PrimitiveType.Capsule, new Vector3(0, 1.28f,-1.12f),    new Vector3(0.14f, 0.42f, 0.14f), mane, new Vector3(35f, 0, 0));
        P(root,  PrimitiveType.Capsule, new Vector3(0, 0.95f,-1.30f),    new Vector3(0.10f, 0.30f, 0.10f), mane);
        // Eyer
        P(root,  PrimitiveType.Cube,    new Vector3(0, 1.52f, 0.05f),    new Vector3(0.60f, 0.10f, 0.72f), saddle);
        P(root,  PrimitiveType.Cube,    new Vector3(0, 1.62f,-0.22f),    new Vector3(0.38f, 0.12f, 0.22f), armorDark);
        P(root,  PrimitiveType.Cube,    new Vector3(0, 1.62f, 0.30f),    new Vector3(0.32f, 0.10f, 0.16f), armorDark);

        // ══ CHAVANDOZ (Jaloliddin Manguberdi) ═══════
        P(root,  PrimitiveType.Cube,    new Vector3(0,    2.02f, 0),     new Vector3(0.48f, 0.25f, 0.30f), armorDark);
        P(root,  PrimitiveType.Cube,    new Vector3(0,    2.36f, 0.02f), new Vector3(0.53f, 0.40f, 0.28f), armor);
        P(root,  PrimitiveType.Cube,    new Vector3(0,    2.36f, 0.18f), new Vector3(0.40f, 0.34f, 0.05f), gold);
        P(root,  PrimitiveType.Cube,    new Vector3(0,    2.30f,-0.16f), new Vector3(0.50f, 0.42f, 0.06f), armorDark);
        // Yelka zirhlar
        P(root,  PrimitiveType.Sphere,  new Vector3(-0.37f,2.58f, 0.02f), new Vector3(0.25f, 0.20f, 0.25f), armor);
        P(root,  PrimitiveType.Sphere,  new Vector3( 0.37f,2.58f, 0.02f), new Vector3(0.25f, 0.20f, 0.25f), armor);
        P(root,  PrimitiveType.Cylinder,new Vector3(-0.40f,2.54f, 0.04f), new Vector3(0.17f, 0.04f, 0.17f), gold);
        P(root,  PrimitiveType.Cylinder,new Vector3( 0.40f,2.54f, 0.04f), new Vector3(0.17f, 0.04f, 0.17f), gold);
        // Mantiya (3 qatlam)
        PR(root, PrimitiveType.Cube,    new Vector3(0,    2.20f,-0.22f), new Vector3(0.50f, 0.62f, 0.06f), cape,     new Vector3(5f,  0,  0));
        PR(root, PrimitiveType.Cube,    new Vector3(-0.13f,1.84f,-0.28f),new Vector3(0.23f, 0.46f, 0.05f), capeDark, new Vector3(12f, 5f, 0));
        PR(root, PrimitiveType.Cube,    new Vector3( 0.13f,1.84f,-0.28f),new Vector3(0.23f, 0.46f, 0.05f), capeDark, new Vector3(12f,-5f, 0));
        // Bosh
        P(root,  PrimitiveType.Sphere,  new Vector3(0,    2.84f, 0.02f), new Vector3(0.36f, 0.37f, 0.36f), skin);
        P(root,  PrimitiveType.Cube,    new Vector3(0,    2.69f, 0.18f), new Vector3(0.18f, 0.09f, 0.06f), new Color(0.18f, 0.10f, 0.05f));
        // Dubulg'a
        P(root,  PrimitiveType.Sphere,  new Vector3(0,    2.98f, 0),     new Vector3(0.43f, 0.29f, 0.43f), helmet);
        P(root,  PrimitiveType.Cube,    new Vector3(0,    2.88f, 0.21f), new Vector3(0.37f, 0.12f, 0.05f), armorDark);
        P(root,  PrimitiveType.Cube,    new Vector3(-0.23f,2.76f, 0.12f),new Vector3(0.07f, 0.19f, 0.09f), helmet);
        P(root,  PrimitiveType.Cube,    new Vector3( 0.23f,2.76f, 0.12f),new Vector3(0.07f, 0.19f, 0.09f), helmet);
        P(root,  PrimitiveType.Cylinder,new Vector3(0,    2.94f, 0),     new Vector3(0.45f, 0.04f, 0.45f), gold);
        P(root,  PrimitiveType.Cylinder,new Vector3(0,    3.22f, 0),     new Vector3(0.07f, 0.25f, 0.07f), gold);
        // Qo'llar
        P(root,  PrimitiveType.Capsule, new Vector3(-0.40f,2.30f, 0.08f),new Vector3(0.14f, 0.28f, 0.14f), armor);
        P(root,  PrimitiveType.Capsule, new Vector3(-0.46f,2.02f, 0.12f),new Vector3(0.13f, 0.22f, 0.13f), armor);
        PR(root, PrimitiveType.Capsule, new Vector3( 0.41f,2.46f, 0.08f),new Vector3(0.14f, 0.30f, 0.14f), armor, new Vector3(0, 0,-28f));
        PR(root, PrimitiveType.Capsule, new Vector3( 0.54f,2.76f, 0.05f),new Vector3(0.12f, 0.28f, 0.12f), armor, new Vector3(0, 0,-14f));
        // Qilich
        PR(root, PrimitiveType.Cube,    new Vector3( 0.64f,3.08f, 0.04f),new Vector3(0.07f, 0.98f, 0.05f), sword, new Vector3(0, 0,-10f));
        P(root,  PrimitiveType.Cube,    new Vector3( 0.62f,2.64f, 0.04f),new Vector3(0.30f, 0.07f, 0.07f), armorDark);
        P(root,  PrimitiveType.Sphere,  new Vector3( 0.60f,2.54f, 0.04f),new Vector3(0.11f, 0.11f, 0.11f), armorDark);
        // Qalqon
        P(root,  PrimitiveType.Cylinder,new Vector3(-0.60f,2.22f, 0.22f),new Vector3(0.47f, 0.05f, 0.47f), shield);
        P(root,  PrimitiveType.Cylinder,new Vector3(-0.60f,2.22f, 0.26f),new Vector3(0.30f, 0.04f, 0.30f), armor);
        P(root,  PrimitiveType.Sphere,  new Vector3(-0.60f,2.22f, 0.30f),new Vector3(0.13f, 0.05f, 0.13f), gold);
        P(root,  PrimitiveType.Cylinder,new Vector3(-0.60f,2.22f, 0.24f),new Vector3(0.48f, 0.03f, 0.48f), armorDark);
        // Oyoqlar
        P(root,  PrimitiveType.Capsule, new Vector3(-0.33f,1.62f, 0.08f),new Vector3(0.15f, 0.24f, 0.15f), armor);
        P(root,  PrimitiveType.Capsule, new Vector3( 0.33f,1.62f, 0.08f),new Vector3(0.15f, 0.24f, 0.15f), armor);
        P(root,  PrimitiveType.Cube,    new Vector3(-0.33f,1.46f, 0.10f),new Vector3(0.17f, 0.16f, 0.23f), armorDark);
        P(root,  PrimitiveType.Cube,    new Vector3( 0.33f,1.46f, 0.10f),new Vector3(0.17f, 0.16f, 0.23f), armorDark);

        // ══ BAYROQ ══════════════════════════════════
        PR(root, PrimitiveType.Cylinder,new Vector3(-0.18f,3.12f,-0.55f),new Vector3(0.05f, 0.90f, 0.05f), armorDark, new Vector3(8f, 0, 0));
        P(root,  PrimitiveType.Cube,    new Vector3( 0.24f,3.85f,-0.62f),new Vector3(0.72f, 0.30f, 0.05f), flagColor);
        P(root,  PrimitiveType.Cube,    new Vector3( 0.24f,3.85f,-0.64f),new Vector3(0.52f, 0.20f, 0.03f),
          new Color(flagColor.r * 0.65f, flagColor.g * 0.65f, flagColor.b * 0.65f));
        P(root,  PrimitiveType.Sphere,  new Vector3(-0.18f,4.04f,-0.65f),new Vector3(0.09f, 0.09f, 0.09f), gold);

        // ══ AURA — oltin halqa + 6 ta nur sferasi ═══
        P(root,  PrimitiveType.Cylinder,new Vector3(0, 3.60f, 0), new Vector3(0.72f, 0.025f, 0.72f), new Color(1f, 0.88f, 0.25f, 0.85f));
        P(root,  PrimitiveType.Cylinder,new Vector3(0, 3.57f, 0), new Vector3(0.48f, 0.020f, 0.48f), new Color(1f, 0.95f, 0.55f, 0.65f));
        for (int i = 0; i < 6; i++)
        {
            float a = i * 60f * Mathf.Deg2Rad;
            P(root, PrimitiveType.Sphere,
              new Vector3(Mathf.Cos(a) * 0.65f, 3.60f, Mathf.Sin(a) * 0.65f),
              new Vector3(0.08f, 0.08f, 0.08f),
              new Color(1f, 0.90f, 0.20f, 0.80f));
        }
    }

    // ─── Yordamchi: oddiy obyekt ──────────────────
    void P(GameObject parent, PrimitiveType type, Vector3 lp, Vector3 ls, Color color)
    {
        GameObject g = GameObject.CreatePrimitive(type);
        g.transform.SetParent(parent.transform);
        g.transform.localPosition = lp;
        g.transform.localScale    = ls;
        SetUnlit(g.GetComponent<Renderer>(), color);
        Destroy(g.GetComponent<Collider>());
    }

    // ─── Yordamchi: burilgan obyekt ───────────────
    void PR(GameObject parent, PrimitiveType type, Vector3 lp, Vector3 ls, Color color, Vector3 euler)
    {
        GameObject g = GameObject.CreatePrimitive(type);
        g.transform.SetParent(parent.transform);
        g.transform.localPosition    = lp;
        g.transform.localScale       = ls;
        g.transform.localEulerAngles = euler;
        SetUnlit(g.GetComponent<Renderer>(), color);
        Destroy(g.GetComponent<Collider>());
    }

    // ─── Unlit/Color shader o'rnatish ─────────────
    static void SetUnlit(Renderer r, Color color)
    {
        Material m = new Material(Shader.Find("Unlit/Color"));
        m.color = color;
        r.material = m;
    }

    public void SelectTower(int index)
    {
        if (configs == null || index >= configs.Length) return;
        Cancel();
        selected = index;
        preview  = GameObject.CreatePrimitive(PrimitiveType.Cube);
        preview.name = "Preview";
        preview.transform.localScale = new Vector3(1.1f, 2.5f, 1.1f);
        Destroy(preview.GetComponent<BoxCollider>());
        Color c = configs[index].color;
        Color bright = new Color(Mathf.Min(c.r+0.3f,1f), Mathf.Min(c.g+0.3f,1f), Mathf.Min(c.b+0.3f,1f));
        SetUnlit(preview.GetComponent<Renderer>(), bright);
        UIManager.Instance?.SetSelected(index);
    }

    public void Cancel()
    {
        if (preview) Destroy(preview);
        selected = -1;
        UIManager.Instance?.SetSelected(-1);
    }

    Vector3 Snap(Vector3 p) => new Vector3(Mathf.Round(p.x), p.y, Mathf.Round(p.z));

}
