// Bu fayl ishlatilmaydi. GameBootstrap.cs kamerani sozlaydi.
