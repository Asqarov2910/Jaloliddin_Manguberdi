using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class GameBootstrap : MonoBehaviour
{
    private static readonly string[] TNames   = { " Minora", "Ballista", "Qozon", "Jaloliddin" };
    private static readonly string[] TDescs   = { "Tez, yaqin", "Kuchli, uzoq", "Ko'p zarba", "Otliq Qo'mondon" };
    private static readonly int[]    TCosts   = { 50, 80, 120, 200 };
    private static readonly float[]  TRanges  = { 6f, 9f, 4f, 11f };
    private static readonly float[]  TRates   = { 1.5f, 0.7f, 2.8f, 2.0f };
    private static readonly int[]    TDamages = { 25, 60, 18, 120 };
    private static readonly Color[]  TColors  = {
        new Color(0.25f, 0.50f, 0.90f),
        new Color(0.55f, 0.12f, 0.12f),
        new Color(0.50f, 0.32f, 0.08f),
        new Color(0.75f, 0.58f, 0.10f),
    };

    void Awake()
    {
        try
        {
            SetupScreen();
            SetupCamera();   // BIRINCHI — kamera har doim mavjud bo'lsin
            CreateLight();
            CreateEnvironment();
            CreateGround();
            CreatePath();
            CreateCastle();
            CreateManagers();
            CreateUI();
        }
        catch (System.Exception e)
        {
            Debug.LogError("[GameBootstrap] Awake xatosi: " + e.Message + "\n" + e.StackTrace);
        }
    }

    // ─── TO'LIQ EKRAN ────────────────────────────
    void SetupScreen()
    {
        Screen.fullScreen = true;
        Screen.sleepTimeout = SleepTimeout.NeverSleep;
    }

    // ─── YORUG'LIQ ────────────────────────────────
    void CreateLight()
    {
        GameObject sun = new GameObject("Sun");
        Light l = sun.AddComponent<Light>();
        l.type      = LightType.Directional;
        l.color     = new Color(1f, 0.95f, 0.78f); // quyosh nuri
        l.intensity = 1.35f;
        sun.transform.rotation = Quaternion.Euler(48f, -35f, 0f);

        // Ambient
        RenderSettings.ambientLight     = new Color(0.32f, 0.30f, 0.26f);
        RenderSettings.ambientIntensity = 0.8f;
    }

    // ─── YASHIL MUHIT ────────────────────────────
    void CreateEnvironment()
    {
        // Katta qoʻngʻir-yashil fon tekisligi (tungi)
        GameObject grass = GameObject.CreatePrimitive(PrimitiveType.Plane);
        grass.name = "GrassTerrain";
        grass.transform.position   = new Vector3(0, -0.05f, 0);
        grass.transform.localScale = new Vector3(22f, 1f, 14f);
        SetUnlit(grass, new Color(0.26f, 0.50f, 0.16f));
        Destroy(grass.GetComponent<MeshCollider>());

        // Soya-maydon: qo'ng'ir yo'l zonasi ostida
        GameObject dirt = GameObject.CreatePrimitive(PrimitiveType.Plane);
        dirt.name = "DirtZone";
        dirt.transform.position   = new Vector3(0, -0.03f, 0);
        dirt.transform.localScale = new Vector3(5.5f, 1f, 4f);
        SetUnlit(dirt, new Color(0.50f, 0.38f, 0.22f));
        Destroy(dirt.GetComponent<MeshCollider>());

        // Daraxtlar — chekkalar bo'ylab
        PlantTrees();

        // Toshlar
        PlaceRocks();
    }

    void PlantTrees()
    {
        // Shimoliy qator
        for (int i = -9; i <= 9; i += 3)
            MakeTree(new Vector3(i, 0, -13f));
        // Janubiy qator
        for (int i = -9; i <= 9; i += 3)
            MakeTree(new Vector3(i, 0, 13f));
        // Chap tomon
        for (int z = -10; z <= 10; z += 4)
            MakeTree(new Vector3(-20f, 0, z));
        // O'ng tomon (qal'a yonida seiyrak)
        for (int z = -10; z <= 10; z += 5)
            MakeTree(new Vector3(26f, 0, z));
        // Ichki bezak daraxlar (yo'ldan chetda)
        int[] zx = { -10, -8, 8, 10 };
        foreach (int z in zx)
        {
            MakeTree(new Vector3(-14f, 0, z));
            MakeTree(new Vector3(14f, 0, z));
        }
    }

    void MakeTree(Vector3 pos)
    {
        // Tasodifiy kattalik
        float s = 0.7f + Random.Range(0f, 0.6f);
        Color trunkCol  = new Color(0.34f + Random.Range(-0.05f,0.05f), 0.22f, 0.08f);
        Color leavesCol = new Color(
            0.12f + Random.Range(0,0.08f),
            0.40f + Random.Range(0,0.12f),
            0.08f + Random.Range(0,0.05f));

        GameObject root = new GameObject("Tree");
        root.transform.position = pos + new Vector3(Random.Range(-0.4f,0.4f), 0, Random.Range(-0.4f,0.4f));

        // Tana
        GameObject trunk = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        trunk.transform.SetParent(root.transform);
        trunk.transform.localPosition = new Vector3(0, 0.6f * s, 0);
        trunk.transform.localScale    = new Vector3(0.22f * s, 0.6f * s, 0.22f * s);
        SetUnlit(trunk, trunkCol);
        Destroy(trunk.GetComponent<CapsuleCollider>());

        // Asosiy barg to'pi
        GameObject leaves1 = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        leaves1.transform.SetParent(root.transform);
        leaves1.transform.localPosition = new Vector3(0, 1.7f * s, 0);
        leaves1.transform.localScale    = new Vector3(1.0f * s, 1.1f * s, 1.0f * s);
        SetUnlit(leaves1, leavesCol);
        Destroy(leaves1.GetComponent<SphereCollider>());

        // Yuqori barg to'pi
        GameObject leaves2 = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        leaves2.transform.SetParent(root.transform);
        leaves2.transform.localPosition = new Vector3(0, 2.5f * s, 0);
        leaves2.transform.localScale    = new Vector3(0.65f * s, 0.75f * s, 0.65f * s);
        SetUnlit(leaves2, Color.Lerp(leavesCol, Color.white, 0.05f));
        Destroy(leaves2.GetComponent<SphereCollider>());
    }

    void PlaceRocks()
    {
        Color rockCol = new Color(0.50f, 0.46f, 0.40f);
        Vector3[] spots = {
            new Vector3(-16f,0,-4f), new Vector3(-16f,0,3f),
            new Vector3( 16f,0,-3f), new Vector3( 16f,0,4f),
            new Vector3(-5f, 0,-9f), new Vector3( 5f, 0,9f),
            new Vector3( 2f, 0,-10f),new Vector3(-3f, 0,10f),
        };
        foreach (Vector3 sp in spots)
        {
            float s = 0.3f + Random.Range(0f, 0.4f);
            GameObject r = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            r.name = "Rock";
            r.transform.position   = sp + new Vector3(0, s * 0.3f, 0);
            r.transform.localScale = new Vector3(s * 1.2f, s * 0.7f, s);
            SetUnlit(r, rockCol);
            Destroy(r.GetComponent<SphereCollider>());
        }
    }

    // ─── YER (JANGOVAR ZONA) ──────────────────────
    void CreateGround()
    {
        GameObject g = GameObject.CreatePrimitive(PrimitiveType.Plane);
        g.name = "Ground";
        g.transform.localScale = new Vector3(5.5f, 1f, 1.5f);
        SetUnlit(g, new Color(0.58f, 0.46f, 0.26f));

        // Yo'l
        GameObject road = GameObject.CreatePrimitive(PrimitiveType.Cube);
        road.name = "Road";
        road.transform.position   = new Vector3(0, 0.02f, 0);
        road.transform.localScale = new Vector3(50f, 0.02f, 2.2f);
        SetUnlit(road, new Color(0.46f, 0.34f, 0.16f));
        Destroy(road.GetComponent<BoxCollider>());

        // Yo'l chekkasi
        GameObject edge1 = GameObject.CreatePrimitive(PrimitiveType.Cube);
        edge1.transform.position   = new Vector3(0, 0.03f, -1.2f);
        edge1.transform.localScale = new Vector3(50f, 0.02f, 0.2f);
        SetUnlit(edge1, new Color(0.32f, 0.24f, 0.10f));
        Destroy(edge1.GetComponent<BoxCollider>());

        GameObject edge2 = GameObject.CreatePrimitive(PrimitiveType.Cube);
        edge2.transform.position   = new Vector3(0, 0.03f, 1.2f);
        edge2.transform.localScale = new Vector3(50f, 0.02f, 0.2f);
        SetUnlit(edge2, new Color(0.32f, 0.24f, 0.10f));
        Destroy(edge2.GetComponent<BoxCollider>());
    }

    // ─── YO'L NUQTALARI ──────────────────────────
    void CreatePath()
    {
        GameObject root = new GameObject("WaypointRoot");
        WaypointPath path = root.AddComponent<WaypointPath>();

        Vector3[] pos = {
            new Vector3(-18f, 0.1f,  5f),
            new Vector3(-10f, 0.1f,  5f),
            new Vector3(-10f, 0.1f, -5f),
            new Vector3(  0f, 0.1f, -5f),
            new Vector3(  0f, 0.1f,  5f),
            new Vector3( 10f, 0.1f,  5f),
            new Vector3( 10f, 0.1f, -2f),
            new Vector3( 16f, 0.1f, -2f),
            new Vector3( 16f, 0.1f,  0f),
        };

        Transform[] pts = new Transform[pos.Length];
        for (int i = 0; i < pos.Length; i++)
        {
            GameObject p = new GameObject("WP" + i);
            p.transform.SetParent(root.transform);
            p.transform.position = pos[i];
            pts[i] = p.transform;
        }
        path.Init(pts);
        WaveManager.SpawnPos = new Vector3(-22f, 0.1f, 5f);

        // ── Yo'l vizualizatsiyasi ──
        Color markCol = new Color(0.95f, 0.55f, 0.05f);
        Color lineCol = new Color(0.90f, 0.45f, 0.05f);

        PathDisc(WaveManager.SpawnPos, 1.0f, new Color(1f, 0.22f, 0.12f)); // spawn — qizil
        Vector3 prev = WaveManager.SpawnPos;
        foreach (Vector3 wp in pos)
        {
            PathSegment(prev, wp, lineCol);
            PathDisc(wp, 0.45f, markCol);
            prev = wp;
        }
    }

    void PathDisc(Vector3 pos, float r, Color color)
    {
        GameObject g = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        g.name = "PathMark";
        g.transform.position   = new Vector3(pos.x, 0.05f, pos.z);
        g.transform.localScale = new Vector3(r * 2f, 0.02f, r * 2f);
        SetUnlit(g, color);
        Destroy(g.GetComponent<Collider>());
    }

    void PathSegment(Vector3 from, Vector3 to, Color color)
    {
        Vector3 f2  = new Vector3(from.x, 0f, from.z);
        Vector3 t2  = new Vector3(to.x,   0f, to.z);
        float dist  = Vector3.Distance(f2, t2);
        if (dist < 0.5f) return;
        Vector3 mid = (f2 + t2) * 0.5f + Vector3.up * 0.04f;
        Vector3 dir = (t2 - f2).normalized;

        GameObject g = GameObject.CreatePrimitive(PrimitiveType.Cube);
        g.name = "PathSeg";
        g.transform.position   = mid;
        g.transform.rotation   = Quaternion.LookRotation(dir);
        g.transform.localScale = new Vector3(0.35f, 0.02f, dist - 0.6f);
        SetUnlit(g, color);
        Destroy(g.GetComponent<BoxCollider>());
    }

    // ─── QAL'A ────────────────────────────────────
    void CreateCastle()
    {
        GameObject root = new GameObject("Castle_Xorazm");
        root.transform.position = new Vector3(18f, 0f, 0f);

        Color stone    = new Color(0.72f, 0.64f, 0.50f);
        Color darkStone= new Color(0.48f, 0.42f, 0.32f);
        Color roof     = new Color(0.38f, 0.30f, 0.20f);
        Color gate     = new Color(0.18f, 0.14f, 0.10f);
        Color wood     = new Color(0.40f, 0.24f, 0.08f);

        // ── Perimetr devori ──
        // Old devor (darvoza bilan)
        CB(root, new Vector3(0,   1.8f, -6f), new Vector3(12f, 3.5f, 0.8f), stone);
        CB(root, new Vector3(0,   1.8f,  6f), new Vector3(12f, 3.5f, 0.8f), stone);
        CB(root, new Vector3(-6f, 1.8f,  0f), new Vector3(0.8f, 3.5f, 12f), stone);
        // O'ng devor (kirish tarafi) — ikki bo'lak, darvoza uchun oraliq
        CB(root, new Vector3(6f, 1.8f, -3.5f), new Vector3(0.8f, 3.5f, 5f), stone);
        CB(root, new Vector3(6f, 1.8f,  3.5f), new Vector3(0.8f, 3.5f, 5f), stone);

        // Darvoza
        CB(root, new Vector3(6f, 0.9f, 0f),  new Vector3(0.7f, 1.8f, 2.8f), gate);
        CB(root, new Vector3(6f, 2.8f, 0f),  new Vector3(0.85f, 1.0f, 2.8f), stone);
        // Darvoza ustuni chap
        CB(root, new Vector3(6f, 1.5f, -1.4f), new Vector3(0.85f, 3f, 0.5f), darkStone);
        // Darvoza ustuni o'ng
        CB(root, new Vector3(6f, 1.5f,  1.4f), new Vector3(0.85f, 3f, 0.5f), darkStone);
        // Darvoza eshigi
        CB(root, new Vector3(6.4f, 1.0f, 0f), new Vector3(0.15f, 1.9f, 2.5f), wood);

        // ── Devor kraynellari (batments) ──
        AddBattlements(root, new Vector3(0, 3.7f, -6f), 12, true,  stone);
        AddBattlements(root, new Vector3(0, 3.7f,  6f), 12, true,  stone);
        AddBattlements(root, new Vector3(-6f, 3.7f, 0f), 12, false, stone);

        // ── 4 ta burchak minorasi ──
        Vector3[] corners = {
            new Vector3(-6f, 0f, -6f), new Vector3( 6f, 0f, -6f),
            new Vector3(-6f, 0f,  6f), new Vector3( 6f, 0f,  6f),
        };
        foreach (Vector3 c in corners)
            BuildCastleTower(root, c, stone, darkStone, roof);

        // ── Ichki keep (asosiy qal'a binosi) ──
        CB(root, new Vector3(-1f, 2.5f, 0f), new Vector3(5f, 5f, 5f), stone);
        CB(root, new Vector3(-1f, 5.2f, 0f), new Vector3(5.5f, 0.4f, 5.5f), darkStone);
        // Keep kraynellari
        Vector3[] kc = {
            new Vector3(-3.2f, 5.7f, -2.7f), new Vector3( 1.2f, 5.7f, -2.7f),
            new Vector3(-3.2f, 5.7f,  2.7f), new Vector3( 1.2f, 5.7f,  2.7f),
        };
        foreach (Vector3 k in kc)
            CB(root, k, new Vector3(0.7f, 0.8f, 0.7f), stone);

        // Keep darchalari
        CB(root, new Vector3(1.6f, 1.2f, 0f), new Vector3(0.1f, 2.2f, 1.4f), gate);

        // ── Bayroqlar ──
        AddFlag(root, new Vector3(-1f, 7.8f, 0f),  new Color(0.8f, 0.1f, 0.1f));
        AddFlag(root, new Vector3(-6f, 6.5f, -6f), new Color(0.7f, 0.6f, 0.0f));
        AddFlag(root, new Vector3( 6f, 6.5f, -6f), new Color(0.7f, 0.6f, 0.0f));
    }

    void BuildCastleTower(GameObject root, Vector3 center, Color stone, Color dark, Color roof)
    {
        CB(root, center + new Vector3(0, 2.2f, 0), new Vector3(2.4f, 4.4f, 2.4f), stone);
        CB(root, center + new Vector3(0, 4.6f, 0), new Vector3(2.8f, 0.35f, 2.8f), dark);
        // Kraynellar
        for (int i = 0; i < 4; i++)
        {
            float a = i * 90f * Mathf.Deg2Rad;
            CB(root,
                center + new Vector3(0, 5.1f, 0)
                       + new Vector3(Mathf.Cos(a) * 0.95f, 0, Mathf.Sin(a) * 0.95f),
                new Vector3(0.55f, 0.75f, 0.55f), stone);
        }
        // Konus tom
        CB(root, center + new Vector3(0, 5.8f, 0), new Vector3(1.4f, 0.5f, 1.4f), roof);
    }

    void AddBattlements(GameObject root, Vector3 start, int count, bool alongX, Color color)
    {
        for (int i = 0; i < count; i += 2)
        {
            Vector3 offset = alongX
                ? new Vector3(-5.5f + i * 1.0f, 0, 0)
                : new Vector3(0, 0, -5.5f + i * 1.0f);
            CB(root, start + offset, new Vector3(0.7f, 0.7f, 0.7f), color);
        }
    }

    void AddFlag(GameObject root, Vector3 pos, Color color)
    {
        CB(root, pos,                          new Vector3(0.12f, 1.8f, 0.12f), new Color(0.3f, 0.22f, 0.1f));
        CB(root, pos + new Vector3(0.4f, 0.5f, 0), new Vector3(0.8f, 0.4f, 0.06f), color);
    }

    void CB(GameObject parent, Vector3 lp, Vector3 ls, Color color)
    {
        GameObject g = GameObject.CreatePrimitive(PrimitiveType.Cube);
        g.transform.SetParent(parent.transform);
        g.transform.localPosition = lp;
        g.transform.localScale    = ls;
        SetUnlit(g, color);
    }

    // ─── KAMERA ───────────────────────────────────
    void SetupCamera()
    {
        Camera cam = Camera.main;
        if (cam == null)
        {
            GameObject g = new GameObject("Main Camera");
            g.tag = "MainCamera";
            cam   = g.AddComponent<Camera>();
            g.AddComponent<AudioListener>();
        }
        cam.transform.position = new Vector3(2f, 35f, -22f);
        cam.transform.rotation = Quaternion.Euler(52f, 0f, 0f);
        cam.fieldOfView        = 58f;
        cam.backgroundColor    = new Color(0.38f, 0.58f, 0.80f); // ko'k osmon
        cam.clearFlags         = CameraClearFlags.SolidColor;
        cam.rect               = new Rect(0, 0, 1, 1);
        RenderSettings.skybox  = null;
        RenderSettings.ambientSkyColor   = new Color(0.50f, 0.68f, 0.88f);
        RenderSettings.ambientGroundColor= new Color(0.22f, 0.38f, 0.14f);
    }

    // ─── MANAGERLAR ───────────────────────────────
    void CreateManagers()
    {
        new GameObject("SoundManager").AddComponent<SoundManager>();
        new GameObject("HeroSystem").AddComponent<HeroSystem>();
        new GameObject("GameManager").AddComponent<GameManager>();
        new GameObject("WaveManager").AddComponent<WaveManager>();

        TowerPlacer placer = new GameObject("TowerPlacer").AddComponent<TowerPlacer>();
        TowerPlacer.TowerConfig[] cfgs = new TowerPlacer.TowerConfig[TNames.Length];
        for (int i = 0; i < TNames.Length; i++)
            cfgs[i] = new TowerPlacer.TowerConfig {
                name=TNames[i], desc=TDescs[i], cost=TCosts[i],
                range=TRanges[i], fireRate=TRates[i], damage=TDamages[i], color=TColors[i]
            };
        placer.SetConfigs(cfgs);
    }

    // ─── UI ───────────────────────────────────────
    void CreateUI()
    {
        GameObject canvasObj = new GameObject("Canvas");
        Canvas canvas = canvasObj.AddComponent<Canvas>();
        canvas.renderMode   = RenderMode.ScreenSpaceOverlay;
        canvas.sortingOrder = 10;
        CanvasScaler cs = canvasObj.AddComponent<CanvasScaler>();
        cs.uiScaleMode         = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        cs.referenceResolution = new Vector2(1080, 1920);
        cs.matchWidthOrHeight  = 0.5f;
        canvasObj.AddComponent<GraphicRaycaster>();

        GameObject es = new GameObject("EventSystem");
        es.AddComponent<UnityEngine.EventSystems.EventSystem>();
        es.AddComponent<UnityEngine.EventSystems.StandaloneInputModule>();

        UIManager ui = new GameObject("UIManager").AddComponent<UIManager>();

        HeroSystem.Instance?.Init(canvas);

        BuildHUD(canvasObj, ui);
        BuildBanner(canvasObj, ui);
        BuildTowerPanel(canvasObj, ui);
        BuildEndScreen(canvasObj, ui);
        BuildStartScreen(canvasObj, ui);
        BuildPauseOverlay(canvasObj, ui);
        BuildPauseButton(canvasObj);
    }

    // ─── HUD ─────────────────────────────────────
    void BuildHUD(GameObject canvas, UIManager ui)
    {
        // Yuqori panel fon
        GameObject panel = MkPanel(canvas,
            new Vector2(0,1), new Vector2(1,1), new Vector2(0,110),
            new Color(0.03f, 0.03f, 0.06f, 0.90f));

        // OLTIN — chap blok
        GameObject goldBlock = MkPanel(panel,
            new Vector2(0,0), new Vector2(0,1), new Vector2(320,0),
            new Color(0f,0f,0f,0f));
        SetAnchored(goldBlock, new Vector2(10, 0));

        MkImg(goldBlock, new Vector2(0,0.5f), new Vector2(44,44), new Color(1f,0.85f,0.1f));
        ui.goldText = MkTxt(goldBlock, "150 oltin",
            new Vector2(52,0), new Vector2(0,0.5f), 38,
            new Color(1f,0.92f,0.4f), TextAlignmentOptions.MidlineLeft);

        // TO'LQIN — markaz blok
        ui.waveText = MkTxt(panel, "To'lqin 0 / 5",
            new Vector2(0, 0), new Vector2(0.5f,0.5f), 38,
            Color.white, TextAlignmentOptions.Midline);

        // QAL'A HP — o'ng blok
        GameObject hpBlock = MkPanel(panel,
            new Vector2(1,0), new Vector2(1,1), new Vector2(310,0),
            new Color(0f,0f,0f,0f));
        SetAnchored(hpBlock, new Vector2(-320, 0));

        MkImg(hpBlock, new Vector2(1,0.5f), new Vector2(40,40), new Color(0.9f,0.15f,0.15f));

        ui.healthText = MkTxt(hpBlock, "20 ❤️",
            new Vector2(-48, 8), new Vector2(1,0.5f), 40,
            Color.white, TextAlignmentOptions.MidlineRight);

        // HP slider
        GameObject slObj = new GameObject("HpSlider");
        slObj.transform.SetParent(hpBlock.transform, false);
        Slider sl = slObj.AddComponent<Slider>();
        RectTransform slRt = slObj.GetComponent<RectTransform>();
        slRt.anchorMin = new Vector2(0,0); slRt.anchorMax = new Vector2(1,0);
        slRt.pivot     = new Vector2(0.5f,0);
        slRt.sizeDelta = new Vector2(-6,14);
        slRt.anchoredPosition = new Vector2(0,10);

        GameObject slBg   = MkImageFull(slObj, new Color(0.28f,0.04f,0.04f));
        GameObject slFill = MkImageFull(slObj, new Color(0.85f,0.12f,0.12f));
        sl.fillRect = slFill.GetComponent<RectTransform>();
        sl.targetGraphic = slBg.GetComponent<Image>();
        sl.minValue=0; sl.maxValue=20; sl.value=20;
        ui.castleHpBar = sl;
    }

    // ─── BANNER ───────────────────────────────────
    void BuildBanner(GameObject canvas, UIManager ui)
    {
        GameObject b = new GameObject("Banner");
        b.transform.SetParent(canvas.transform, false);
        b.AddComponent<Image>().color = new Color(0.018f, 0.014f, 0.048f, 0.96f);
        b.AddComponent<CanvasGroup>();
        RectTransform rt = b.GetComponent<RectTransform>();
        rt.anchorMin = new Vector2(0.06f,0.52f);
        rt.anchorMax = new Vector2(0.94f,0.52f);
        rt.pivot     = new Vector2(0.5f,0.5f);
        rt.sizeDelta = new Vector2(0,165);

        GameObject line = MkImageFull(b, new Color(0.8f,0.65f,0.08f));
        RectTransform lrt = line.GetComponent<RectTransform>();
        lrt.anchorMin=new Vector2(0,1); lrt.anchorMax=new Vector2(1,1);
        lrt.sizeDelta=new Vector2(0,5); lrt.anchoredPosition=Vector2.zero;

        TextMeshProUGUI txt = MkTxt(b,"",Vector2.zero,
            new Vector2(0.5f,0.5f),50,new Color(1f,0.88f,0.3f),TextAlignmentOptions.Center);
        RectTransform trt = txt.GetComponent<RectTransform>();
        trt.anchorMin=Vector2.zero; trt.anchorMax=Vector2.one;
        trt.offsetMin=new Vector2(16,8); trt.offsetMax=new Vector2(-16,-8);

        ui.banner=b; ui.bannerText=txt;
        b.SetActive(false);
    }

    // ─── MINORA PANELI ────────────────────────────
    void BuildTowerPanel(GameObject canvas, UIManager ui)
    {
        // Panel — past chiziq, to'q qoʻngʻir-qora
        GameObject panel = new GameObject("TowerPanel");
        panel.transform.SetParent(canvas.transform, false);
        panel.AddComponent<Image>().color = new Color(0.06f, 0.05f, 0.10f, 0.97f);
        RectTransform panRt = panel.GetComponent<RectTransform>();
        panRt.anchorMin = Vector2.zero; panRt.anchorMax = new Vector2(1, 0);
        panRt.pivot     = new Vector2(0.5f, 0f);
        panRt.sizeDelta = new Vector2(0, 160);

        // Yuqori oltin ajratgich
        var tl = new GameObject("TopLine"); tl.transform.SetParent(panel.transform, false);
        tl.AddComponent<Image>().color = new Color(0.80f, 0.62f, 0.10f);
        var tlrt = tl.GetComponent<RectTransform>();
        tlrt.anchorMin = new Vector2(0,1); tlrt.anchorMax = new Vector2(1,1);
        tlrt.sizeDelta = new Vector2(0, 3); tlrt.anchoredPosition = Vector2.zero;

        // Har bir minora uchun asosiy rang (to'q, professional)
        Color[] baseCols = {
            new Color(0.10f, 0.18f, 0.52f), // Minora — chuqur navy
            new Color(0.48f, 0.07f, 0.07f), // Ballista — to'q qizil
            new Color(0.40f, 0.22f, 0.03f), // Qozon — to'q amber
            new Color(0.38f, 0.27f, 0.02f), // Jaloliddin — to'q oltin
        };
        Color[] shineCols = {
            new Color(0.30f, 0.50f, 0.95f, 0.22f),
            new Color(0.85f, 0.18f, 0.18f, 0.22f),
            new Color(0.80f, 0.45f, 0.08f, 0.22f),
            new Color(0.88f, 0.65f, 0.10f, 0.22f),
        };
        string[] symbols = { "▲", "⟹", "◉", "★" };

        int   count = TNames.Length;
        Image[]           bgs   = new Image[count];
        TextMeshProUGUI[] costs = new TextMeshProUGUI[count];

        float[] cx = { 0.12f, 0.33f, 0.54f, 0.75f };
        const float BW = 208f, BH = 130f;

        for (int i = 0; i < count; i++)
        {
            bool isHero = (i == 3);
            int  idx    = i;

            // ── Button asosi ────────────────────────
            var go  = new GameObject("TBtn" + i);
            var bg  = RndImg(go, baseCols[i]);
            go.transform.SetParent(panel.transform, false);
            bgs[i] = bg;

            var rt = go.GetComponent<RectTransform>();
            rt.anchorMin = rt.anchorMax = new Vector2(cx[i], 0.52f);
            rt.pivot     = new Vector2(0.5f, 0.5f);
            rt.sizeDelta = new Vector2(BW, BH);

            // Yuqori yarmi yorqin overlay — oddiy to'rtburchak (RndImg emas!)
            var sh  = new GameObject("Sh");
            sh.transform.SetParent(go.transform, false);
            sh.AddComponent<Image>().color = shineCols[i];
            var shRt = sh.GetComponent<RectTransform>();
            shRt.anchorMin = new Vector2(0, 0.5f); shRt.anchorMax = Vector2.one;
            shRt.offsetMin = shRt.offsetMax = Vector2.zero;

            // Yuqori rang chizig'i (tor, tower rangi)
            var stripe = new GameObject("Stripe");
            stripe.transform.SetParent(go.transform, false);
            stripe.AddComponent<Image>().color = TColors[i];
            var srt = stripe.GetComponent<RectTransform>();
            srt.anchorMin = new Vector2(0.08f, 1f); srt.anchorMax = new Vector2(0.92f, 1f);
            srt.pivot     = new Vector2(0.5f, 1f);
            srt.sizeDelta = new Vector2(0, 5); srt.anchoredPosition = new Vector2(0, -1f);

            // Pastki yupqa ajratgich chiziq
            var div = new GameObject("Div");
            div.transform.SetParent(go.transform, false);
            div.AddComponent<Image>().color = new Color(1f, 1f, 1f, 0.08f);
            var dvrt = div.GetComponent<RectTransform>();
            dvrt.anchorMin = new Vector2(0.05f, 0.38f); dvrt.anchorMax = new Vector2(0.95f, 0.38f);
            dvrt.sizeDelta = new Vector2(0, 1); dvrt.anchoredPosition = Vector2.zero;

            // ── Click ────────────────────────────────
            var btn = go.AddComponent<Button>();
            btn.targetGraphic = bg;
            btn.onClick.AddListener(() => TowerPlacer.Instance?.SelectTower(idx));
            var cb = btn.colors;
            cb.normalColor      = Color.white;
            cb.highlightedColor = new Color(1.18f, 1.18f, 1.18f);
            cb.pressedColor     = new Color(0.78f, 0.78f, 0.78f);
            cb.fadeDuration     = 0.08f;
            btn.colors = cb;

            // ── Matnlar (band bo'yicha) ───────────────
            // 1) Symbol (yuqori, kichik, tower rangi)
            BandTxt(go, symbols[i], isHero ? 17 : 15, TColors[i], 0.82f, 1.00f, FontStyles.Bold);

            // 2) Minora nomi (asosiy, oq, katta)
            BandTxt(go, TNames[i].Trim(), isHero ? 24 : 27,
                Color.white, isHero ? 0.56f : 0.52f, 0.84f, FontStyles.Bold);

            // 3) "QAHRAMON" nishoni (faqat hero uchun)
            if (isHero)
                BandTxt(go, "QAHRAMON", 14, new Color(1f, 0.82f, 0.15f), 0.40f, 0.56f);

            // 4) Narx (oltin rang)
            var ct = BandTxt(go, "◆ " + TCosts[i],
                isHero ? 18 : 20, new Color(1f, 0.88f, 0.18f),
                isHero ? 0.20f : 0.18f, isHero ? 0.40f : 0.44f, FontStyles.Bold);
            costs[i] = ct;

            // 5) Zarar + diapazon (pastki, yashilroq)
            BandTxt(go, "Zarar " + TDamages[i] + "  ·  D:" + (int)TRanges[i],
                13, new Color(0.52f, 0.84f, 0.56f), 0.02f, 0.20f);
        }

        ui.towerBtnBgs     = bgs;
        ui.towerCostTexts  = costs;
        ui.towerBaseColors = baseCols;

        // ── BEKOR tugmasi (o'ng, qizil pill) ─────────
        var cancelGo = new GameObject("CancelBtn");
        var cImg     = RndImg(cancelGo, new Color(0.52f, 0.06f, 0.06f));
        cancelGo.transform.SetParent(panel.transform, false);
        var cancelBtn = cancelGo.AddComponent<Button>();
        cancelBtn.targetGraphic = cImg;
        cancelBtn.onClick.AddListener(() => TowerPlacer.Instance?.Cancel());
        var ccb = cancelBtn.colors;
        ccb.normalColor = Color.white; ccb.highlightedColor = new Color(1.20f,1.20f,1.20f);
        ccb.pressedColor = new Color(0.75f,0.75f,0.75f); cancelBtn.colors = ccb;
        var crt = cancelGo.GetComponent<RectTransform>();
        crt.anchorMin = crt.anchorMax = new Vector2(0.90f, 0.52f);
        crt.pivot     = new Vector2(0.5f, 0.5f);
        crt.sizeDelta = new Vector2(138, 90);
        BandTxt(cancelGo, "✕",     32, new Color(1f, 0.42f, 0.42f), 0.52f, 1.00f, FontStyles.Bold);
        BandTxt(cancelGo, "BEKOR", 19, Color.white,                  0.05f, 0.50f, FontStyles.Bold);

        ui.cancelBtn = cancelGo;
        cancelGo.SetActive(false);
        ui.SetCosts(TCosts);
    }

    // ─── O'YIN TUGASHI ────────────────────────────
    void BuildEndScreen(GameObject canvas, UIManager ui)
    {
        GameObject overlay = new GameObject("EndOverlay");
        overlay.transform.SetParent(canvas.transform,false);
        overlay.AddComponent<Image>().color = new Color(0f,0f,0f,0.78f);
        RectTransform ort = overlay.GetComponent<RectTransform>();
        ort.anchorMin=Vector2.zero; ort.anchorMax=Vector2.one;
        ort.offsetMin=ort.offsetMax=Vector2.zero;

        GameObject panel = new GameObject("EndPanel");
        panel.transform.SetParent(overlay.transform,false);
        panel.AddComponent<Image>().color = new Color(0.05f,0.04f,0.09f,0.97f);
        RectTransform prt = panel.GetComponent<RectTransform>();
        prt.anchorMin=new Vector2(0.08f,0.32f); prt.anchorMax=new Vector2(0.92f,0.70f);
        prt.offsetMin=prt.offsetMax=Vector2.zero;

        GameObject tl = MkImageFull(panel, new Color(0.8f,0.65f,0.08f));
        RectTransform tlrt = tl.GetComponent<RectTransform>();
        tlrt.anchorMin=new Vector2(0,1); tlrt.anchorMax=new Vector2(1,1);
        tlrt.sizeDelta=new Vector2(0,5); tlrt.anchoredPosition=Vector2.zero;

        ui.endTitle = MkTxt(panel,"",new Vector2(0,-52),
            new Vector2(0.5f,1f),75,new Color(1f,0.85f,0.14f),TextAlignmentOptions.Top);

        ui.endSub = MkTxt(panel,"",new Vector2(0,10),
            new Vector2(0.5f,0.5f),34,new Color(0.84f,0.84f,0.84f),TextAlignmentOptions.Center);

        // Restart — compact pill, panelning pastida markazda
        var btnObj = new GameObject("RestartBtn");
        Image restImg = RndImg(btnObj, new Color(0.10f, 0.42f, 0.12f));
        btnObj.transform.SetParent(panel.transform, false);
        Button btn = btnObj.AddComponent<Button>();
        btn.targetGraphic = restImg;
        var rcb = btn.colors;
        rcb.normalColor = Color.white; rcb.highlightedColor = new Color(1.18f,1.18f,1.18f);
        rcb.pressedColor = new Color(0.78f,0.78f,0.78f); btn.colors = rcb;
        var brt = btnObj.GetComponent<RectTransform>();
        brt.anchorMin = brt.anchorMax = new Vector2(0.5f, 0f);
        brt.pivot     = new Vector2(0.5f, 0f);
        brt.sizeDelta = new Vector2(310, 64); brt.anchoredPosition = new Vector2(0, 22);
        var rSh = new GameObject("Sh"); rSh.transform.SetParent(btnObj.transform, false);
        rSh.AddComponent<Image>().color = new Color(0.22f,0.72f,0.25f,0.22f);
        var rShRt = rSh.GetComponent<RectTransform>();
        rShRt.anchorMin = new Vector2(0,0.5f); rShRt.anchorMax = Vector2.one;
        rShRt.offsetMin = rShRt.offsetMax = Vector2.zero;
        BandTxt(btnObj, "↺  QAYTA BOSHLASH", 30, Color.white, 0.08f, 0.92f, FontStyles.Bold);

        ui.restartBtn = btn; ui.endPanel = overlay;
        overlay.SetActive(false);
    }

    // ─── START EKRANI ────────────────────────────
    void BuildStartScreen(GameObject canvas, UIManager ui)
    {
        Color gold      = new Color(0.92f, 0.76f, 0.14f);
        Color goldLight = new Color(1.00f, 0.94f, 0.52f);
        Color panelBg   = new Color(0.06f, 0.05f, 0.10f, 0.98f);

        // To'liq ekran fon
        GameObject overlay = new GameObject("StartScreen");
        overlay.transform.SetParent(canvas.transform, false);
        overlay.AddComponent<Image>().color = new Color(0.04f, 0.03f, 0.08f, 0.97f);
        overlay.AddComponent<CanvasGroup>();
        RectTransform ort = overlay.GetComponent<RectTransform>();
        ort.anchorMin = Vector2.zero; ort.anchorMax = Vector2.one;
        ort.offsetMin = ort.offsetMax = Vector2.zero;

        // ── Sarlavha paneli ───────────────────────
        var titlePanel = new GameObject("TitlePanel");
        titlePanel.transform.SetParent(overlay.transform, false);
        titlePanel.AddComponent<Image>().color = panelBg;
        var tpr = titlePanel.GetComponent<RectTransform>();
        tpr.anchorMin = new Vector2(0.04f, 0.58f); tpr.anchorMax = new Vector2(0.96f, 0.96f);
        tpr.offsetMin = tpr.offsetMax = Vector2.zero;

        // Yuqori oltin chiziq
        SsLine(titlePanel, 1f, gold, 4f);
        // Pastki chiziq
        SsLine(titlePanel, 0f, new Color(gold.r, gold.g, gold.b, 0.5f), 2f);

        // "JALOLIDDIN"
        SsTxt(titlePanel, "JALOLIDDIN", 80, gold, FontStyles.Bold,
              new Vector2(0, 0.55f), new Vector2(1, 0.98f), 5f);

        // "MANGUBERDI"
        SsTxt(titlePanel, "MANGUBERDI", 62, goldLight, FontStyles.Bold,
              new Vector2(0, 0.26f), new Vector2(1, 0.60f), 3f);

        // Tavsif (italic)
        SsTxt(titlePanel,
              "Xorazm qal'asini mo'g'ullardan himoya qil!", 27,
              new Color(0.76f, 0.76f, 0.85f), FontStyles.Italic,
              new Vector2(0.04f, 0.03f), new Vector2(0.96f, 0.28f));

        // ── DARAJA sarlavhasi ─────────────────────
        SsTxt(overlay,
              "— QIYINCHILIK DARAJASINI TANLANG —", 28,
              new Color(0.85f, 0.85f, 0.92f), FontStyles.Bold,
              new Vector2(0.04f, 0.50f), new Vector2(0.96f, 0.58f), 2f);

        // ── 3 ta daraja tugmasi ───────────────────
        var lvl = new (string icon, string name, string sub1, string sub2,
                       Color bg, Color accent, GameManager.GameLevel lv)[]
        {
            ("★", "OSON",   "4 to'lqin",  "Ko'p sog'liq · Ko'proq oltin",
             new Color(0.06f,0.28f,0.09f), new Color(0.28f,0.92f,0.35f), GameManager.GameLevel.Easy),
            ("⚔", "O'RTA",  "5 to'lqin",  "O'rtacha qiyinlik",
             new Color(0.36f,0.20f,0.02f), new Color(0.98f,0.80f,0.14f), GameManager.GameLevel.Medium),
            ("☠", "QIYIN",  "6 to'lqin",  "Chingizxon o'zi keladi!",
             new Color(0.36f,0.04f,0.04f), new Color(1.00f,0.28f,0.22f), GameManager.GameLevel.Hard),
        };

        float[] lcx = { 0.17f, 0.50f, 0.83f };
        const float LW = 295f, LH = 158f;

        for (int i = 0; i < 3; i++)
        {
            var d = lvl[i]; int idx = i;

            // Karta (soya yo'q)
            var card = new GameObject("Lvl"+i); var cbg = RndImg(card, d.bg);
            card.transform.SetParent(overlay.transform, false);
            var cr = card.GetComponent<RectTransform>();
            cr.anchorMin = cr.anchorMax = new Vector2(lcx[i], 0.30f);
            cr.pivot = new Vector2(0.5f,0.5f); cr.sizeDelta = new Vector2(LW, LH);

            // Yuqori accent chiziq
            var al = new GameObject("AL"); al.transform.SetParent(card.transform, false);
            al.AddComponent<Image>().color = d.accent;
            var alr = al.GetComponent<RectTransform>();
            alr.anchorMin=new Vector2(0.06f,1f); alr.anchorMax=new Vector2(0.94f,1f);
            alr.pivot=new Vector2(0.5f,1f); alr.sizeDelta=new Vector2(0,4);

            // Button
            var btn = card.AddComponent<Button>(); btn.targetGraphic = cbg;
            btn.onClick.AddListener(()=>{
                GameManager.selectedLevel = lvl[idx].lv;
                GameManager.Instance?.StartGame();
            });
            var bc = btn.colors;
            bc.normalColor=Color.white; bc.highlightedColor=new Color(1.16f,1.16f,1.16f);
            bc.pressedColor=new Color(0.80f,0.80f,0.80f); bc.fadeDuration=0.08f;
            btn.colors=bc;

            // Ikon
            BandTxt(card, d.icon, 44, d.accent,                         0.66f,1.00f, FontStyles.Bold);
            // Nom
            BandTxt(card, d.name, 38, Color.white,                       0.40f,0.68f, FontStyles.Bold);
            // To'lqin
            BandTxt(card, d.sub1, 22, new Color(0.88f,0.88f,0.95f),     0.22f,0.42f, FontStyles.Bold);
            // Tavsif
            var dt = BandTxt(card, d.sub2, 17, new Color(0.65f,0.70f,0.75f), 0.02f,0.24f);
            dt.fontStyle = FontStyles.Italic;
        }

        // Pastki hint
        SsTxt(overlay, "▼  Darajani bosing — o'yin boshlanadi  ▼", 24,
              new Color(0.44f,0.46f,0.54f), FontStyles.Italic,
              new Vector2(0.05f,0.13f), new Vector2(0.95f,0.20f));

        ui.startScreen = overlay;
    }

    // Yordamchi: sarlavha panelida gorizontal chiziq
    void SsLine(GameObject parent, float anchorY, Color color, float h)
    {
        var g = new GameObject("L"); g.transform.SetParent(parent.transform, false);
        g.AddComponent<Image>().color = color;
        var rt = g.GetComponent<RectTransform>();
        rt.anchorMin = new Vector2(0, anchorY); rt.anchorMax = new Vector2(1, anchorY);
        rt.sizeDelta = new Vector2(0, h); rt.anchoredPosition = Vector2.zero;
    }

    // Yordamchi: full-anchor TextMeshPro
    TextMeshProUGUI SsTxt(GameObject parent, string text, int size, Color color,
        FontStyles style, Vector2 aMin, Vector2 aMax, float spacing = 0f)
    {
        var g = new GameObject("T"); g.transform.SetParent(parent.transform, false);
        var t = g.AddComponent<TextMeshProUGUI>();
        t.text = text; t.fontSize = size; t.color = color;
        t.fontStyle = style; t.alignment = TextAlignmentOptions.Center;
        t.characterSpacing = spacing;
        var rt = g.GetComponent<RectTransform>();
        rt.anchorMin = aMin; rt.anchorMax = aMax;
        rt.offsetMin = rt.offsetMax = Vector2.zero;
        return t;
    }

    // ─── PAUZA OVERLAY ────────────────────────────
    void BuildPauseOverlay(GameObject canvas, UIManager ui)
    {
        GameObject overlay = new GameObject("PauseOverlay");
        overlay.transform.SetParent(canvas.transform, false);
        overlay.AddComponent<Image>().color = new Color(0f, 0f, 0f, 0.80f);
        RectTransform ort = overlay.GetComponent<RectTransform>();
        ort.anchorMin = Vector2.zero; ort.anchorMax = Vector2.one;
        ort.offsetMin = ort.offsetMax = Vector2.zero;

        // Panel
        GameObject panel = new GameObject("PausePanel");
        panel.transform.SetParent(overlay.transform, false);
        panel.AddComponent<Image>().color = new Color(0.05f, 0.04f, 0.10f, 0.97f);
        RectTransform prt = panel.GetComponent<RectTransform>();
        prt.anchorMin = new Vector2(0.15f, 0.38f);
        prt.anchorMax = new Vector2(0.85f, 0.65f);
        prt.offsetMin = prt.offsetMax = Vector2.zero;

        // Sarlavha
        GameObject titleObj = new GameObject("PauseTitle");
        titleObj.transform.SetParent(panel.transform, false);
        TextMeshProUGUI titleTxt = titleObj.AddComponent<TextMeshProUGUI>();
        titleTxt.text = "⏸  PAUZA";
        titleTxt.fontSize = 62; titleTxt.fontStyle = FontStyles.Bold;
        titleTxt.color = new Color(1f, 0.88f, 0.25f);
        titleTxt.alignment = TextAlignmentOptions.Center;
        RectTransform trt = titleObj.GetComponent<RectTransform>();
        trt.anchorMin = new Vector2(0, 0.55f); trt.anchorMax = new Vector2(1, 0.98f);
        trt.offsetMin = trt.offsetMax = Vector2.zero;

        // DAVOM ET — compact pill, panelning chap-qismi
        var resumeObj = new GameObject("ResumeBtn");
        Image resumeImg = RndImg(resumeObj, new Color(0.07f,0.42f,0.10f));
        resumeObj.transform.SetParent(panel.transform, false);
        Button resumeBtn = resumeObj.AddComponent<Button>();
        resumeBtn.targetGraphic = resumeImg;
        resumeBtn.onClick.AddListener(() => GameManager.Instance?.ResumeGame());
        var rcb2 = resumeBtn.colors;
        rcb2.normalColor = Color.white; rcb2.highlightedColor = new Color(1.20f,1.20f,1.20f);
        rcb2.pressedColor = new Color(0.78f,0.78f,0.78f); resumeBtn.colors = rcb2;
        var rrt = resumeObj.GetComponent<RectTransform>();
        rrt.anchorMin = rrt.anchorMax = new Vector2(0.30f, 0.22f);
        rrt.pivot     = new Vector2(0.5f, 0.5f);
        rrt.sizeDelta = new Vector2(220, 60);
        var rSh2 = new GameObject("Sh"); rSh2.transform.SetParent(resumeObj.transform, false);
        rSh2.AddComponent<Image>().color = new Color(0.20f,0.72f,0.24f,0.18f);
        rSh2.GetComponent<RectTransform>().anchorMin = new Vector2(0,0.5f);
        rSh2.GetComponent<RectTransform>().anchorMax = Vector2.one;
        BandTxt(resumeObj, "▶  DAVOM ET", 26, Color.white, 0.08f,0.92f, FontStyles.Bold);

        // QAYTA — compact pill, o'ng tomon
        var restartObj = new GameObject("RestartBtn2");
        Image restImg2 = RndImg(restartObj, new Color(0.48f,0.06f,0.06f));
        restartObj.transform.SetParent(panel.transform, false);
        Button restartBtn2 = restartObj.AddComponent<Button>();
        restartBtn2.targetGraphic = restImg2;
        restartBtn2.onClick.AddListener(() => GameManager.Instance?.RestartGame());
        var r2cb = restartBtn2.colors;
        r2cb.normalColor = Color.white; r2cb.highlightedColor = new Color(1.20f,1.20f,1.20f);
        r2cb.pressedColor = new Color(0.78f,0.78f,0.78f); restartBtn2.colors = r2cb;
        var r2rt = restartObj.GetComponent<RectTransform>();
        r2rt.anchorMin = r2rt.anchorMax = new Vector2(0.70f, 0.22f);
        r2rt.pivot     = new Vector2(0.5f, 0.5f);
        r2rt.sizeDelta = new Vector2(220, 60);
        var r2Sh = new GameObject("Sh"); r2Sh.transform.SetParent(restartObj.transform, false);
        r2Sh.AddComponent<Image>().color = new Color(0.80f,0.14f,0.14f,0.18f);
        r2Sh.GetComponent<RectTransform>().anchorMin = new Vector2(0,0.5f);
        r2Sh.GetComponent<RectTransform>().anchorMax = Vector2.one;
        BandTxt(restartObj, "↺  QAYTA", 26, Color.white, 0.08f,0.92f, FontStyles.Bold);

        ui.pauseOverlay = overlay;
        overlay.SetActive(false);
    }

    // ─── PAUZA TUGMASI ───────────────────────────
    void BuildPauseButton(GameObject canvas)
    {
        var btn = new GameObject("PauseBtn");
        Image pauseImg = RndImg(btn, new Color(0.08f, 0.08f, 0.22f, 0.92f));
        btn.transform.SetParent(canvas.transform, false);
        Button b = btn.AddComponent<Button>();
        b.targetGraphic = pauseImg;
        b.onClick.AddListener(() => GameManager.Instance?.TogglePause());
        var pcb = b.colors;
        pcb.normalColor = Color.white; pcb.highlightedColor = new Color(1.22f,1.22f,1.22f);
        pcb.pressedColor = new Color(0.72f,0.72f,0.72f); b.colors = pcb;
        var rt = btn.GetComponent<RectTransform>();
        rt.anchorMin = rt.anchorMax = new Vector2(0.930f, 0.907f);
        rt.pivot     = new Vector2(0.5f, 0.5f);
        rt.sizeDelta = new Vector2(148, 46);
        BandTxt(btn, "⏸ PAUZA", 24, new Color(0.80f, 0.84f, 1f), 0f, 1f, FontStyles.Bold);
    }

    // ─── YORDAMCHI ────────────────────────────────
    GameObject MkPanel(GameObject parent,
        Vector2 ancMin, Vector2 ancMax, Vector2 size, Color color)
    {
        GameObject g = new GameObject("Panel");
        g.transform.SetParent(parent.transform,false);
        g.AddComponent<Image>().color = color;
        RectTransform rt = g.GetComponent<RectTransform>();
        rt.anchorMin=ancMin; rt.anchorMax=ancMax;
        rt.pivot=ancMin; rt.sizeDelta=size; rt.anchoredPosition=Vector2.zero;
        return g;
    }

    void SetAnchored(GameObject g, Vector2 pos)
    {
        g.GetComponent<RectTransform>().anchoredPosition = pos;
    }

    TextMeshProUGUI MkTxt(GameObject parent, string text,
        Vector2 aPos, Vector2 anchor, int size, Color color, TextAlignmentOptions align)
    {
        GameObject g = new GameObject("T");
        g.transform.SetParent(parent.transform,false);
        TextMeshProUGUI t = g.AddComponent<TextMeshProUGUI>();
        t.text=text; t.fontSize=size; t.color=color; t.alignment=align;
        RectTransform rt = g.GetComponent<RectTransform>();
        rt.anchorMin=rt.anchorMax=anchor; rt.pivot=anchor;
        rt.sizeDelta=new Vector2(460,55); rt.anchoredPosition=aPos;
        return t;
    }

    TextMeshProUGUI BtnTxt(GameObject parent, string text, Vector2 aPos,
        int size, Color color,
        TextAlignmentOptions align = TextAlignmentOptions.MidlineLeft,
        Vector2 anchor = default)
    {
        if (anchor == default) anchor = new Vector2(0, 0.5f);
        TextMeshProUGUI t = MkTxt(parent, text, aPos, anchor, size, color, align);
        t.GetComponent<RectTransform>().sizeDelta = new Vector2(250, 46);
        return t;
    }

    // Tugma ichida anchor (0-1) bo'yicha joylashuvchi matn
    TextMeshProUGUI AnchoredTxt(GameObject parent, string text,
        Vector2 anchor, int size, Color color, TextAlignmentOptions align)
    {
        GameObject g = new GameObject("T");
        g.transform.SetParent(parent.transform, false);
        TextMeshProUGUI t = g.AddComponent<TextMeshProUGUI>();
        t.text = text; t.fontSize = size; t.color = color; t.alignment = align;
        RectTransform rt = g.GetComponent<RectTransform>();
        rt.anchorMin = new Vector2(0.05f, anchor.y - 0.12f);
        rt.anchorMax = new Vector2(0.95f, anchor.y + 0.12f);
        rt.offsetMin = rt.offsetMax = Vector2.zero;
        return t;
    }

    void MkImg(GameObject parent, Vector2 anchor, Vector2 size, Color color)
    {
        GameObject g = new GameObject("Img");
        g.transform.SetParent(parent.transform,false);
        g.AddComponent<Image>().color = color;
        RectTransform rt = g.GetComponent<RectTransform>();
        rt.anchorMin=rt.anchorMax=anchor; rt.pivot=anchor;
        rt.sizeDelta=size; rt.anchoredPosition=Vector2.zero;
    }

    GameObject MkImageFull(GameObject parent, Color color)
    {
        GameObject g = new GameObject("Img");
        g.transform.SetParent(parent.transform,false);
        g.AddComponent<Image>().color=color;
        RectTransform rt = g.GetComponent<RectTransform>();
        rt.anchorMin=Vector2.zero; rt.anchorMax=Vector2.one;
        rt.offsetMin=rt.offsetMax=Vector2.zero;
        return g;
    }

    // ─── UNLIT HELPER ─────────────────────────────
    static Shader s_UnlitShader;
    static void SetUnlit(GameObject g, Color color)
    {
        if (s_UnlitShader == null)
            s_UnlitShader = Shader.Find("Unlit/Color") ?? Shader.Find("Standard") ?? Shader.Find("Mobile/Unlit (Supports Lightmap)");
        if (s_UnlitShader == null) return;
        Material mat = new Material(s_UnlitShader);
        mat.color = color;
        var rend = g.GetComponent<Renderer>();
        if (rend != null) rend.material = mat;
    }

    // ─── ROUNDED SPRITE (9-slice, istalgan o'lcham) ──
    static Sprite s_Rnd;
    static Sprite RndSpr()
    {
        if (s_Rnd != null) return s_Rnd;
        const int S = 128, R = 32;
        var tex = new Texture2D(S, S, TextureFormat.RGBA32, false);
        tex.filterMode = FilterMode.Bilinear;
        var px = new Color[S * S];
        for (int y = 0; y < S; y++)
        for (int x = 0; x < S; x++)
        {
            float cx = x < R ? R : x > S-R-1 ? S-R-1 : x;
            float cy = y < R ? R : y > S-R-1 ? S-R-1 : y;
            float d  = Mathf.Sqrt((x-cx)*(x-cx)+(y-cy)*(y-cy));
            px[y*S+x] = new Color(1f, 1f, 1f, Mathf.Clamp01(R - d + 1.5f));
        }
        tex.SetPixels(px); tex.Apply();
        s_Rnd = Sprite.Create(tex, new Rect(0,0,S,S), new Vector2(.5f,.5f),
            100f, 0, SpriteMeshType.FullRect, new Vector4(R,R,R,R));
        return s_Rnd;
    }

    // Rounded image yaratish yordamchisi
    static Image RndImg(GameObject g, Color c)
    {
        Image img = g.AddComponent<Image>();
        img.sprite = RndSpr();
        img.type   = Image.Type.Sliced;
        img.color  = c;
        return img;
    }

    // Rounded button yaratish (to'liq rangli, shaded)
    static Button MkRndBtn(GameObject parent, Color baseCol, Color highlightCol,
                            Vector2 ancMin, Vector2 ancMax, string name = "Btn")
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(parent.transform, false);

        Image bg = RndImg(go, baseCol);
        RectTransform rt = go.GetComponent<RectTransform>();
        rt.anchorMin = ancMin; rt.anchorMax = ancMax;
        rt.offsetMin = rt.offsetMax = Vector2.zero;

        // Yuqori yarim — oddiy to'rtburchak overlay
        GameObject shine = new GameObject("Shine");
        shine.transform.SetParent(go.transform, false);
        shine.AddComponent<Image>().color = highlightCol;
        RectTransform srt = shine.GetComponent<RectTransform>();
        srt.anchorMin = new Vector2(0f, 0.48f); srt.anchorMax = Vector2.one;
        srt.offsetMin = srt.offsetMax = Vector2.zero;

        Button btn = go.AddComponent<Button>();
        btn.targetGraphic = bg;
        var cb = btn.colors;
        cb.normalColor      = Color.white;
        cb.highlightedColor = new Color(1.15f, 1.15f, 1.15f);
        cb.pressedColor     = new Color(0.80f, 0.80f, 0.80f);
        cb.fadeDuration     = 0.08f;
        btn.colors = cb;
        return btn;
    }

    // TMP matn (to'liq anchor bo'yicha)
    static TextMeshProUGUI FullTxt(GameObject parent, string text, int size,
                                    Color color, FontStyles style = FontStyles.Normal,
                                    TextAlignmentOptions align = TextAlignmentOptions.Center)
    {
        GameObject g = new GameObject("T");
        g.transform.SetParent(parent.transform, false);
        var t = g.AddComponent<TextMeshProUGUI>();
        t.text = text; t.fontSize = size; t.color = color;
        t.fontStyle = style; t.alignment = align;
        t.enableWordWrapping = false;
        var rt = g.GetComponent<RectTransform>();
        rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one;
        rt.offsetMin = new Vector2(4, 0); rt.offsetMax = new Vector2(-4, 0);
        return t;
    }

    // Anchor bo'yicha matn (button ichida, ixcham)
    static TextMeshProUGUI BandTxt(GameObject parent, string text, int size, Color color,
                                    float yMin, float yMax,
                                    FontStyles style = FontStyles.Normal,
                                    TextAlignmentOptions align = TextAlignmentOptions.Center)
    {
        var g = new GameObject("T");
        g.transform.SetParent(parent.transform, false);
        var t = g.AddComponent<TextMeshProUGUI>();
        t.text               = text;
        t.fontSize           = size;
        t.color              = color;
        t.fontStyle          = style;
        t.alignment          = align;
        t.enableWordWrapping = false;
        t.overflowMode       = TextOverflowModes.Ellipsis;
        var rt = g.GetComponent<RectTransform>();
        rt.anchorMin = new Vector2(0.02f, yMin);
        rt.anchorMax = new Vector2(0.98f, yMax);
        rt.offsetMin = rt.offsetMax = Vector2.zero;
        return t;
    }

    // ── EDITOR PREVIEW (Play bosmasdan ko'rinadi) ──
    void OnDrawGizmos()
    {
        // Dushman yo'li
        Vector3[] wps = {
            new Vector3(-22, 0, 5),  // spawn
            new Vector3(-18, 0, 5),  new Vector3(-10, 0, 5),
            new Vector3(-10, 0,-5),  new Vector3(  0, 0,-5),
            new Vector3(  0, 0, 5),  new Vector3( 10, 0, 5),
            new Vector3( 10, 0,-2),  new Vector3( 16, 0,-2),
            new Vector3( 16, 0, 0),
        };

        // Spawn belgisi
        Gizmos.color = new Color(1f, 0.2f, 0.1f);
        Gizmos.DrawSphere(wps[0], 1.0f);

        // Yo'l chiziqlari
        Gizmos.color = new Color(1f, 0.55f, 0.05f);
        for (int i = 1; i < wps.Length; i++)
        {
            Gizmos.DrawLine(wps[i-1], wps[i]);
            Gizmos.DrawSphere(wps[i], 0.45f);
        }

        // Qal'a joylashuvi
        Gizmos.color = new Color(1f, 0.9f, 0.2f);
        Gizmos.DrawWireCube(new Vector3(18, 2.5f, 0), new Vector3(12, 5, 12));

        // Jangovar maydon
        Gizmos.color = new Color(0.35f, 0.65f, 0.2f, 0.4f);
        Gizmos.DrawWireCube(Vector3.zero, new Vector3(55, 0.1f, 15));

#if UNITY_EDITOR
        UnityEditor.Handles.Label(new Vector3(-20, 2, 8),
            "JALOLIDDIN MANGUBERDI\nPlay bosing →");
#endif
    }
}
