using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;
using System.IO;

public class AndroidBuilder
{
    static readonly string UnityAndroidRoot =
        "C:/Program Files/Unity/Hub/Editor/2022.3.62f3/Editor/Data/PlaybackEngines/AndroidPlayer";

    public static void BuildAPK()
    {
        string outputDir  = "C:/Users/abror/OneDrive/Desktop/Jaloliddin_Manguberdi";
        string outputPath = outputDir + "/JaloliddinManguberdi.apk";

        // SDK — foydalanuvchi lokal (yozish huquqi bor)
        EditorPrefs.SetString("AndroidSdkRoot",
            "C:/Users/abror/AppData/Local/Android/Sdk");
        // NDK va JDK — Unity bundled (o'qish yetarli)
        EditorPrefs.SetString("AndroidNdkRootR16b",
            UnityAndroidRoot + "/NDK");
        EditorPrefs.SetString("JdkPath",
            UnityAndroidRoot + "/OpenJDK");

        // Player settings
        PlayerSettings.companyName           = "XorazmStudios";
        PlayerSettings.productName           = "Jaloliddin Manguberdi";
        PlayerSettings.applicationIdentifier = "com.xorazm.jaloliddinmanguberdi";
        PlayerSettings.bundleVersion         = "1.0";
        PlayerSettings.Android.bundleVersionCode  = 1;
        PlayerSettings.Android.minSdkVersion      = AndroidSdkVersions.AndroidApiLevel22;
        PlayerSettings.Android.targetSdkVersion   = AndroidSdkVersions.AndroidApiLevel34;
        PlayerSettings.Android.targetArchitectures= AndroidArchitecture.ARMv7 | AndroidArchitecture.ARM64;
        PlayerSettings.SetScriptingBackend(BuildTargetGroup.Android, ScriptingImplementation.Mono2x);
        PlayerSettings.defaultInterfaceOrientation          = UIOrientation.LandscapeLeft;
        PlayerSettings.allowedAutorotateToLandscapeLeft     = true;
        PlayerSettings.allowedAutorotateToLandscapeRight    = true;
        PlayerSettings.allowedAutorotateToPortrait          = false;
        PlayerSettings.allowedAutorotateToPortraitUpsideDown= false;

        BuildPlayerOptions opts = new BuildPlayerOptions
        {
            scenes           = new[] { "Assets/Scenes/SampleScene.unity" },
            locationPathName = outputPath,
            target           = BuildTarget.Android,
            options          = BuildOptions.None,
        };

        Debug.Log("APK build boshlanmoqda: " + outputPath);
        BuildReport report = BuildPipeline.BuildPlayer(opts);

        if (report.summary.result == BuildResult.Succeeded)
            Debug.Log("✓ APK tayyor: " + outputPath +
                      " | Hajm: " + (report.summary.totalSize / 1024 / 1024) + " MB");
        else
            Debug.LogError("✗ APK xato: " + report.summary.result +
                           " | " + report.summary.totalErrors + " ta xato");
    }
}
